package com.ciallo.hyperbackground;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

final class BackgroundApplier {
    private static final String HOME_SESSION = "hyperbackground.home.session";
    private static final String GLOBAL_SESSION = "hyperbackground.global.session";
    private static final String DEVICE_SESSION = "hyperbackground.device.session";
    private static final String DEVICE_ACTIVE = "hyperbackground.device.active";
    private static final String ORIGINAL_TEXT_COLOR = "hyperbackground.original.text.color";

    private BackgroundApplier() {}

    static void applyHome(Activity activity) {
        if (activity == null) return;
        removeGlobalIfAny(activity);
        applyLayer(activity, BackgroundContract.HOME, HOME_SESSION, true);
        applyFontMode(activity);
    }

    static void stopHome(Activity activity) { stopLayer(activity, HOME_SESSION); }

    static void applyGlobal(Activity activity) {
        if (activity == null || isHome(activity) || isDeviceActive(activity)) return;
        applyLayer(activity, BackgroundContract.GLOBAL, GLOBAL_SESSION, false);
        applyFontMode(activity);
    }

    static void stopGlobal(Activity activity) { stopLayer(activity, GLOBAL_SESSION); }

    private static boolean isHome(Activity activity) {
        return "com.android.settings.MiuiSettings".equals(activity.getClass().getName());
    }

    private static boolean isDeviceActive(Activity activity) {
        return Boolean.TRUE.equals(XposedHelpers.getAdditionalInstanceField(activity, DEVICE_ACTIVE));
    }

    private static void applyLayer(Activity activity, String slot, String fieldKey, boolean home) {
        try {
            BackgroundContract.Source source = BackgroundContract.query(activity, slot);
            LayerSession old = (LayerSession) XposedHelpers.getAdditionalInstanceField(activity, fieldKey);
            if (!source.exists) { if (old != null) removeLayer(activity, fieldKey, old); return; }
            if (old != null && old.media.sourceKey().equals(source.cacheKey())) { old.media.onHostResume(); return; }
            if (old != null) removeLayer(activity, fieldKey, old);

            View contentView = activity.findViewById(android.R.id.content);
            if (!(contentView instanceof ViewGroup)) return;
            ViewGroup content = (ViewGroup) contentView;
            View originalRoot = content.getChildCount() > 0 ? content.getChildAt(0) : null;
            BackgroundMediaView media = new BackgroundMediaView(activity, source);
            ViewGroup.LayoutParams mediaParams = content instanceof FrameLayout
                    ? new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    : new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

            LayerSession session = new LayerSession(media);
            session.clear(content);
            if (originalRoot != null) session.clear(originalRoot);
            clearNamed(activity, session, "nestedheaderlayout");
            clearNamed(activity, session, "scroll_headers");
            clearNamed(activity, session, "main_content");
            if (!home) {
                clearNamed(activity, session, "prefs_container");
                clearNamed(activity, session, "preference_recyclerview");
                clearNamed(activity, session, "recycler_view");
            }
            content.addView(media, 0, mediaParams);
            XposedHelpers.setAdditionalInstanceField(activity, fieldKey, session);
        } catch (Throwable error) { log("applyLayer/" + slot, error); }
    }

    private static void stopLayer(Activity activity, String fieldKey) {
        if (activity == null) return;
        try {
            LayerSession s = (LayerSession) XposedHelpers.getAdditionalInstanceField(activity, fieldKey);
            if (s != null) s.media.onHostStop();
        } catch (Throwable error) { log("stopLayer", error); }
    }

    private static void removeLayer(Activity activity, String fieldKey, LayerSession session) {
        XposedHelpers.removeAdditionalInstanceField(activity, fieldKey);
        ViewGroup parent = session.media.getParent() instanceof ViewGroup ? (ViewGroup) session.media.getParent() : null;
        if (parent != null) parent.removeView(session.media);
        session.media.dispose();
        session.restore();
    }

    private static void removeGlobalIfAny(Activity activity) {
        try {
            LayerSession s = (LayerSession) XposedHelpers.getAdditionalInstanceField(activity, GLOBAL_SESSION);
            if (s != null) removeLayer(activity, GLOBAL_SESSION, s);
        } catch (Throwable error) { log("removeGlobal", error); }
    }

    static boolean shouldSuppressDeviceShader(Object fragment) {
        try {
            Context context = contextFromFragment(fragment);
            return context != null && BackgroundContract.query(context, BackgroundContract.DEVICE).exists;
        } catch (Throwable error) { log("shouldSuppressDeviceShader", error); return false; }
    }

    static void applyDevice(Object fragment) {
        if (fragment == null) return;
        try {
            Context context = contextFromFragment(fragment); if (context == null) return;
            Activity activity = activityFromFragment(fragment);
            if (activity != null) { XposedHelpers.setAdditionalInstanceField(activity, DEVICE_ACTIVE, Boolean.TRUE); removeGlobalIfAny(activity); }
            BackgroundContract.Source source = BackgroundContract.query(context, BackgroundContract.DEVICE);
            DeviceSession old = (DeviceSession) XposedHelpers.getAdditionalInstanceField(fragment, DEVICE_SESSION);
            if (!source.exists) { if (old != null) removeDevice(fragment, old, true); if (activity != null) applyFontMode(activity); return; }
            if (old != null && old.media.sourceKey().equals(source.cacheKey())) { stopOriginalShader(fragment, old.backgroundView); old.media.onHostResume(); if (activity != null) applyFontMode(activity); return; }
            int rememberedVisibility = old != null ? old.originalVisibility : Integer.MIN_VALUE;
            Object field = XposedHelpers.getObjectField(fragment, "mBgEffectView"); if (!(field instanceof View)) return;
            View backgroundView = (View) field; if (!(backgroundView.getParent() instanceof ViewGroup)) return;
            ViewGroup parent = (ViewGroup) backgroundView.getParent(); BackgroundMediaView media = new BackgroundMediaView(context, source);
            if (old != null) removeDevice(fragment, old, false); stopOriginalShader(fragment, backgroundView);
            int index = parent.indexOfChild(backgroundView); if (index < 0) index = 0;
            try { parent.addView(media, index + 1, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)); }
            catch (Throwable e) { media.dispose(); backgroundView.setVisibility(rememberedVisibility != Integer.MIN_VALUE ? rememberedVisibility : View.VISIBLE); throw e; }
            DeviceSession session = new DeviceSession(backgroundView, rememberedVisibility != Integer.MIN_VALUE ? rememberedVisibility : backgroundView.getVisibility(), media);
            backgroundView.setVisibility(View.INVISIBLE); XposedHelpers.setAdditionalInstanceField(fragment, DEVICE_SESSION, session);
            if (activity != null) applyFontMode(activity);
        } catch (Throwable error) { log("applyDevice", error); }
    }

    static void stopDevice(Object fragment) {
        if (fragment == null) return;
        try { DeviceSession s = (DeviceSession) XposedHelpers.getAdditionalInstanceField(fragment, DEVICE_SESSION); if (s != null) s.media.onHostStop(); }
        catch (Throwable error) { log("stopDevice", error); }
    }

    static void destroyDevice(Object fragment) {
        if (fragment == null) return;
        try {
            DeviceSession session = (DeviceSession) XposedHelpers.removeAdditionalInstanceField(fragment, DEVICE_SESSION);
            if (session != null) removeDeviceView(session, false);
            Activity activity = activityFromFragment(fragment);
            if (activity != null) { XposedHelpers.removeAdditionalInstanceField(activity, DEVICE_ACTIVE); applyGlobal(activity); }
        } catch (Throwable error) { log("destroyDevice", error); }
    }

    static void applyFontMode(Activity activity) {
        if (activity == null) return;
        try {
            BackgroundContract.Source s = BackgroundContract.query(activity, BackgroundContract.GLOBAL);
            View root = activity.findViewById(android.R.id.content); if (root == null) return;
            applyTextRecursive(root, s.fontMode);
        } catch (Throwable error) { log("applyFontMode", error); }
    }

    private static void applyTextRecursive(View view, int mode) {
        if (view instanceof TextView) {
            TextView tv = (TextView) view;
            Object saved = XposedHelpers.getAdditionalInstanceField(tv, ORIGINAL_TEXT_COLOR);
            if (mode == BackgroundContract.FONT_FOLLOW) {
                if (saved instanceof Integer) { tv.setTextColor((Integer) saved); XposedHelpers.removeAdditionalInstanceField(tv, ORIGINAL_TEXT_COLOR); }
            } else {
                if (!(saved instanceof Integer)) XposedHelpers.setAdditionalInstanceField(tv, ORIGINAL_TEXT_COLOR, tv.getCurrentTextColor());
                tv.setTextColor(mode == BackgroundContract.FONT_LIGHT ? Color.WHITE : Color.rgb(24, 24, 26));
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) view; for (int i = 0; i < g.getChildCount(); i++) applyTextRecursive(g.getChildAt(i), mode);
        }
    }

    private static void removeDevice(Object fragment, DeviceSession session, boolean restoreBackground) {
        XposedHelpers.removeAdditionalInstanceField(fragment, DEVICE_SESSION); removeDeviceView(session, restoreBackground);
    }
    private static void removeDeviceView(DeviceSession session, boolean restoreBackground) {
        ViewGroup parent = session.media.getParent() instanceof ViewGroup ? (ViewGroup) session.media.getParent() : null;
        if (parent != null) parent.removeView(session.media); session.media.dispose();
        if (restoreBackground) session.backgroundView.setVisibility(session.originalVisibility);
    }
    private static void stopOriginalShader(Object fragment, View backgroundView) {
        try { Object controller = XposedHelpers.getObjectField(fragment, "mBgEffectController"); if (controller != null) XposedHelpers.callMethod(controller, "stop"); } catch (Throwable ignored) {}
        try { backgroundView.setRenderEffect(null); } catch (Throwable ignored) {}
    }
    private static Context contextFromFragment(Object fragment) {
        Object context = XposedHelpers.callMethod(fragment, "getContext"); if (context instanceof Context) return (Context) context;
        Object activity = XposedHelpers.callMethod(fragment, "getActivity"); return activity instanceof Context ? (Context) activity : null;
    }
    private static Activity activityFromFragment(Object fragment) {
        try { Object a = XposedHelpers.callMethod(fragment, "getActivity"); return a instanceof Activity ? (Activity) a : null; } catch (Throwable ignored) { return null; }
    }
    private static void clearNamed(Activity activity, LayerSession session, String name) {
        int id = activity.getResources().getIdentifier(name, "id", "com.android.settings"); if (id == 0) return;
        View view = activity.findViewById(id); if (view != null) session.clear(view);
    }
    private static void log(String stage, Throwable error) { XposedBridge.log("[HyperBackground] " + stage + " failed: " + error); XposedBridge.log(error); }

    private static final class LayerSession {
        final BackgroundMediaView media; final List<View> clearedViews = new ArrayList<>(); final List<Drawable> originalBackgrounds = new ArrayList<>();
        LayerSession(BackgroundMediaView media) { this.media = media; }
        void clear(View view) { if (clearedViews.contains(view)) return; clearedViews.add(view); originalBackgrounds.add(view.getBackground()); view.setBackground(null); }
        void restore() { for (int i = 0; i < clearedViews.size(); i++) clearedViews.get(i).setBackground(originalBackgrounds.get(i)); clearedViews.clear(); originalBackgrounds.clear(); }
    }
    private static final class DeviceSession {
        final View backgroundView; final int originalVisibility; final BackgroundMediaView media;
        DeviceSession(View backgroundView, int originalVisibility, BackgroundMediaView media) { this.backgroundView = backgroundView; this.originalVisibility = originalVisibility; this.media = media; }
    }
}

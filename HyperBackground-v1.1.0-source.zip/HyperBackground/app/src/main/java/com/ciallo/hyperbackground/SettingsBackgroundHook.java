package com.ciallo.hyperbackground;

import android.app.Activity;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class SettingsBackgroundHook implements IXposedHookLoadPackage {
    private static final String TARGET_PACKAGE = "com.android.settings";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PACKAGE.equals(lpparam.packageName)) return;
        hookGenericSettingsActivity(lpparam.classLoader);
        hookHomeActivity(lpparam.classLoader);
        hookHomeFragment(lpparam.classLoader);
        hookDeviceFragment(lpparam.classLoader);
    }


    private static void hookGenericSettingsActivity(ClassLoader classLoader) {
        try {
            XposedHelpers.findAndHookMethod(
                    "com.android.settings.SettingsActivity",
                    classLoader,
                    "onResume",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (param.thisObject instanceof Activity) {
                                Activity activity = (Activity) param.thisObject;
                                if ("com.android.settings.MiuiSettings".equals(activity.getClass().getName())) {
                                    BackgroundApplier.applyHome(activity);
                                } else {
                                    BackgroundApplier.applyGlobal(activity);
                                }
                            }
                        }
                    });
            XposedHelpers.findAndHookMethod(
                    "com.android.settings.SettingsActivity",
                    classLoader,
                    "onStop",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (param.thisObject instanceof Activity) {
                                Activity activity = (Activity) param.thisObject;
                                BackgroundApplier.stopGlobal(activity);
                                BackgroundApplier.stopHome(activity);
                            }
                        }
                    });
        } catch (Throwable error) {
            logHookError("SettingsActivity", error);
        }
    }

    private static void hookHomeActivity(ClassLoader classLoader) {
        try {
            XposedHelpers.findAndHookMethod(
                    "com.android.settings.MiuiSettings",
                    classLoader,
                    "onCreate",
                    Bundle.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (param.thisObject instanceof Activity) {
                                BackgroundApplier.applyHome((Activity) param.thisObject);
                            }
                        }
                    });

            XposedHelpers.findAndHookMethod(
                    "com.android.settings.MiuiSettings",
                    classLoader,
                    "onResume",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (param.thisObject instanceof Activity) {
                                BackgroundApplier.applyHome((Activity) param.thisObject);
                            }
                        }
                    });

            XposedHelpers.findAndHookMethod(
                    "com.android.settings.MiuiSettings",
                    classLoader,
                    "onStop",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (param.thisObject instanceof Activity) {
                                BackgroundApplier.stopHome((Activity) param.thisObject);
                            }
                        }
                    });
        } catch (Throwable error) {
            logHookError("MiuiSettings", error);
        }
    }

    private static void hookHomeFragment(ClassLoader classLoader) {
        try {
            XposedHelpers.findAndHookMethod(
                    "com.android.settings.SettingsFragment",
                    classLoader,
                    "onViewCreated",
                    android.view.View.class,
                    Bundle.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            Object activity = XposedHelpers.callMethod(param.thisObject, "getActivity");
                            if (activity instanceof Activity) {
                                BackgroundApplier.applyHome((Activity) activity);
                            }
                        }
                    });
        } catch (Throwable error) {
            logHookError("SettingsFragment", error);
        }
    }

    private static void hookDeviceFragment(ClassLoader classLoader) {
        final String className = "com.android.settings.device.MiuiMyDeviceSettings";
        try {
            XposedHelpers.findAndHookMethod(
                    className,
                    classLoader,
                    "startRuntimeShader",
                    boolean.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (BackgroundApplier.shouldSuppressDeviceShader(param.thisObject)) {
                                param.setResult(null);
                            }
                        }
                    });

            XposedHelpers.findAndHookMethod(
                    className,
                    classLoader,
                    "setDeviceShaderBackground",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            BackgroundApplier.applyDevice(param.thisObject);
                        }
                    });

            XposedHelpers.findAndHookMethod(
                    className,
                    classLoader,
                    "onResume",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            BackgroundApplier.applyDevice(param.thisObject);
                        }
                    });

            XposedHelpers.findAndHookMethod(
                    className,
                    classLoader,
                    "onStop",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            BackgroundApplier.stopDevice(param.thisObject);
                        }
                    });

            XposedHelpers.findAndHookMethod(
                    className,
                    classLoader,
                    "onDestroy",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            BackgroundApplier.destroyDevice(param.thisObject);
                        }
                    });
        } catch (Throwable error) {
            logHookError("MiuiMyDeviceSettings", error);
        }
    }

    private static void logHookError(String target, Throwable error) {
        XposedBridge.log("[HyperBackground] Could not hook " + target + ": " + error);
        XposedBridge.log(error);
    }
}

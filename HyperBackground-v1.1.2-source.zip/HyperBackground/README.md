# HyperBackground 1.1.2

面向 HyperOS 4 / Android 17 设置应用的 LSPosed 背景模块。

## 1.1.2

- 设置主页与“我的设备”保持两条完全独立的背景通道，不再提供全局背景。
- 修复实际 APK 版本号仍停留在 1.1.0 的问题；当前 `versionName=1.1.2`、`versionCode=3`。
- 可视化主题色调色盘改为实时联动：HEX、色相、饱和度、明度、预览块和对话框按钮会同步变色。
- 应用主题色后保留原滚动位置，不再强制跳回页面顶部。
- 模块本体新增 **跟随系统 / 浅色 / 深色** 三种界面模式。
- 模块本体新增自定义背景，支持透明度、模糊开关和模糊强度。
- 使用自定义杯子图片作为模块图标，并同步用于作者头像。
- 作者卡增加酷安主页与 GitHub 仓库快捷入口。

## 背景通道

### 设置主页

只作用于 `com.android.settings.MiuiSettings`，支持 JPG / PNG / WebP / GIF，并可独立设置透明度和模糊。

### 我的设备

只作用于 `com.android.settings.device.MiuiMyDeviceSettings`，支持图片、GIF / 动态 WebP、无声循环 MP4 / WebM，并可独立设置透明度和模糊。

## 模块本体外观

- 跟随系统 / 浅色 / 深色。
- 壁纸 Monet 自动取色。
- 可视化 HSV 调色盘与 HEX 输入。
- 自定义模块背景图片 / GIF / WebP。
- 模块背景透明度 0–100%。
- Android 12+ 模块背景 RenderEffect 模糊 0–80。

## 字体颜色

Settings 背景页面可选择：

- 跟随系统
- 强制浅色文字
- 强制深色文字

## 作者

制作者：**苍簇**

- 酷安：`https://www.coolapk.com/u/18795532`
- GitHub：`https://github.com/Solomonstery/HyperBackground`

## 构建

需要 Android SDK Platform 35、Build Tools 35.0.1、Java 17。

```sh
chmod +x build.sh
./build.sh
```

输出：`dist/HyperBackground-v1.1.2.apk`

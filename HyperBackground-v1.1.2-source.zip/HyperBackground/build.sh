#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
ANDROID_SDK_DIR="${ANDROID_SDK_ROOT:-$PROJECT_DIR/../tools/android-sdk}"
ANDROID_JAR="$ANDROID_SDK_DIR/platforms/android-35/android.jar"
BUILD_TOOLS="$ANDROID_SDK_DIR/build-tools/35.0.1"
JAVA_RUNTIME="${JAVA_RUNTIME:-/usr/lib/jvm/java-17-openjdk-amd64}"
ECJ_JAR="$PROJECT_DIR/tools/ecj-3.46.0.jar"

export PATH="$JAVA_RUNTIME/bin:$PATH"
export LD_LIBRARY_PATH="$JAVA_RUNTIME/lib:$BUILD_TOOLS/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

if [[ ! -f "$ANDROID_JAR" ]]; then
  echo "Missing Android SDK platform: $ANDROID_JAR" >&2
  exit 1
fi
if [[ ! -x "$BUILD_TOOLS/aapt2" || ! -x "$BUILD_TOOLS/d8" ]]; then
  echo "Missing Android build-tools 35.0.1: $BUILD_TOOLS" >&2
  exit 1
fi
if [[ ! -f "$ECJ_JAR" ]]; then
  echo "Missing Eclipse compiler: $ECJ_JAR" >&2
  exit 1
fi

BUILD_DIR="$PROJECT_DIR/build"
DIST_DIR="$PROJECT_DIR/dist"
SIGNING_DIR="$PROJECT_DIR/signing"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/compiled" "$BUILD_DIR/generated" "$BUILD_DIR/stubs" \
  "$BUILD_DIR/classes" "$BUILD_DIR/dex" "$DIST_DIR" "$SIGNING_DIR"

"$BUILD_TOOLS/aapt2" compile \
  --dir "$PROJECT_DIR/app/src/main/res" \
  -o "$BUILD_DIR/compiled/resources.zip"

"$BUILD_TOOLS/aapt2" link \
  -I "$ANDROID_JAR" \
  --manifest "$PROJECT_DIR/app/src/main/AndroidManifest.xml" \
  -A "$PROJECT_DIR/app/src/main/assets" \
  --java "$BUILD_DIR/generated" \
  --min-sdk-version 28 \
  --target-sdk-version 35 \
  --version-code 3 \
  --version-name 1.1.2 \
  -o "$BUILD_DIR/unsigned.apk" \
  "$BUILD_DIR/compiled/resources.zip"

STUB_SOURCES="$(find "$PROJECT_DIR/compile-stubs" -name '*.java' -print | sort)"
"$JAVA_RUNTIME/bin/java" -jar "$ECJ_JAR" \
  -1.8 -proc:none -nowarn \
  -classpath "$ANDROID_JAR" \
  -d "$BUILD_DIR/stubs" \
  $STUB_SOURCES

APP_SOURCES="$(find "$PROJECT_DIR/app/src/main/java" "$BUILD_DIR/generated" -name '*.java' -print | sort)"
"$JAVA_RUNTIME/bin/java" -jar "$ECJ_JAR" \
  -1.8 -proc:none -nowarn \
  -classpath "$ANDROID_JAR:$BUILD_DIR/stubs" \
  -d "$BUILD_DIR/classes" \
  $APP_SOURCES

(cd "$BUILD_DIR/classes" && zip -qr "$BUILD_DIR/app-classes.jar" .)
"$BUILD_TOOLS/d8" \
  --lib "$ANDROID_JAR" \
  --min-api 28 \
  --output "$BUILD_DIR/dex" \
  "$BUILD_DIR/app-classes.jar"

(cd "$BUILD_DIR/dex" && zip -q -u "$BUILD_DIR/unsigned.apk" classes.dex)
(cd "$PROJECT_DIR/module-meta" && zip -q -u "$BUILD_DIR/unsigned.apk" META-INF/xposed/scope.list)

"$BUILD_TOOLS/zipalign" -f 4 \
  "$BUILD_DIR/unsigned.apk" \
  "$BUILD_DIR/aligned.apk"

KEYSTORE="$SIGNING_DIR/hyperbackground-debug.jks"
if [[ ! -f "$KEYSTORE" ]]; then
  "$JAVA_RUNTIME/bin/keytool" -genkeypair \
    -keystore "$KEYSTORE" \
    -storepass hyperbackground \
    -keypass hyperbackground \
    -alias hyperbackground \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -dname "CN=HyperBackground Debug,O=HyperBackground,C=CN" \
    >/dev/null 2>&1
fi

OUTPUT="$DIST_DIR/HyperBackground-v1.1.2.apk"
"$BUILD_TOOLS/apksigner" sign \
  --ks "$KEYSTORE" \
  --ks-key-alias hyperbackground \
  --ks-pass pass:hyperbackground \
  --key-pass pass:hyperbackground \
  --out "$OUTPUT" \
  "$BUILD_DIR/aligned.apk"

"$BUILD_TOOLS/apksigner" verify --verbose "$OUTPUT"
"$BUILD_TOOLS/aapt2" dump badging "$OUTPUT" | sed -n '1,8p'
echo "Built: $OUTPUT"

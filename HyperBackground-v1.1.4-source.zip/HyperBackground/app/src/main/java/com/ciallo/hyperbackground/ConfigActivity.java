package com.ciallo.hyperbackground;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperColors;
import android.app.WallpaperManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public final class ConfigActivity extends Activity {
    private static final int REQUEST_HOME = 1001;
    private static final int REQUEST_DEVICE = 1002;
    private static final int REQUEST_UI_BACKGROUND = 1003;
    private static final long MAX_FILE_SIZE = 200L * 1024L * 1024L;

    private SharedPreferences prefs;
    private int accent;
    private int bg;
    private int card;
    private int primary;
    private int secondary;
    private boolean darkUi;
    private ScrollView mainScroll;
    private TextView homeStatus;
    private TextView deviceStatus;
    private TextView uiBgStatus;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(BackgroundContract.PREFS, 0);
        resolveTheme();
        configureSystemBars();
        setContentView(buildContent());
        refreshStatus();
        final int y = prefs.getInt(BackgroundContract.UI_SCROLL_Y, 0);
        prefs.edit().remove(BackgroundContract.UI_SCROLL_Y).apply();
        if (mainScroll != null && y > 0) mainScroll.post(() -> mainScroll.scrollTo(0, y));
    }

    private void resolveTheme() {
        int mode = prefs.getInt(BackgroundContract.UI_THEME_MODE, BackgroundContract.UI_THEME_FOLLOW);
        boolean systemDark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        darkUi = mode == BackgroundContract.UI_THEME_DARK || (mode == BackgroundContract.UI_THEME_FOLLOW && systemDark);

        boolean monet = prefs.getBoolean(BackgroundContract.UI_MONET, true);
        accent = prefs.getInt(BackgroundContract.UI_ACCENT, Color.rgb(105, 128, 255));
        if (monet) {
            try {
                WallpaperColors colors = WallpaperManager.getInstance(this).getWallpaperColors(WallpaperManager.FLAG_SYSTEM);
                if (colors != null && colors.getPrimaryColor() != null) accent = colors.getPrimaryColor().toArgb();
            } catch (Throwable ignored) {}
        }

        if (darkUi) {
            bg = Color.rgb(16, 17, 20);
            card = Color.rgb(31, 32, 36);
            primary = Color.rgb(242, 242, 247);
            secondary = Color.rgb(174, 174, 178);
        } else {
            bg = Color.rgb(245, 246, 250);
            card = Color.WHITE;
            primary = Color.rgb(28, 28, 30);
            secondary = Color.rgb(112, 112, 118);
        }
    }

    private void configureSystemBars() {
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        int flags = 0;
        if (!darkUi) {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    private View buildContent() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(bg);
        addUiBackground(root);

        mainScroll = new ScrollView(this);
        mainScroll.setFillViewport(true);
        mainScroll.setBackgroundColor(Color.TRANSPARENT);
        root.addView(mainScroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(24), dp(18), dp(38));
        mainScroll.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("HyperBackground", 30, primary);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        content.addView(title);
        TextView subtitle = text("HyperOS 设置背景 · 首页 / 我的设备双独立通道", 14, secondary);
        LinearLayout.LayoutParams sp = wrap(); sp.topMargin = dp(5); sp.bottomMargin = dp(20); content.addView(subtitle, sp);

        homeStatus = addBackgroundCard(content, BackgroundContract.HOME, "设置首页", "只作用于设置主页，与“我的设备”完全独立", false);
        deviceStatus = addBackgroundCard(content, BackgroundContract.DEVICE, "我的设备", "独立通道；支持图片、GIF、动态 WebP、MP4/WebM", true);
        addFontCard(content);
        addSettingsThemeModeCard(content);
        addThemeCard(content);
        addAuthorCard(content);

        Button info = button("打开模块应用信息", false);
        info.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });
        LinearLayout.LayoutParams ip = match(); ip.topMargin = dp(4); content.addView(info, ip);
        return root;
    }

    private void addUiBackground(FrameLayout root) {
        File file = new File(getFilesDir(), "ui_background.bin");
        if (!file.isFile()) return;
        try {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setAlpha(prefs.getInt(BackgroundContract.UI_BG_OPACITY, 100) / 100f);
            Drawable drawable = ImageDecoder.decodeDrawable(ImageDecoder.createSource(file));
            image.setImageDrawable(drawable);
            if (drawable instanceof AnimatedImageDrawable) ((AnimatedImageDrawable) drawable).start();
            if (Build.VERSION.SDK_INT >= 31 && prefs.getBoolean(BackgroundContract.UI_BG_BLUR_ENABLED, false)) {
                float radius = prefs.getInt(BackgroundContract.UI_BG_BLUR_RADIUS, 20);
                if (radius > 0f) image.setRenderEffect(RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP));
            }
            root.addView(image, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } catch (Throwable ignored) {}
    }

    private TextView addBackgroundCard(LinearLayout parent, String slot, String titleText, String description, boolean video) {
        LinearLayout box = cardBox();
        TextView title = text(titleText, 20, primary); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); box.addView(title);
        TextView desc = text(description, 13, secondary); LinearLayout.LayoutParams dp1 = wrap(); dp1.topMargin = dp(4); box.addView(desc, dp1);
        TextView status = text("跟随系统默认", 13, accent); LinearLayout.LayoutParams stp = wrap(); stp.topMargin = dp(12); box.addView(status, stp);

        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button choose = button(video ? "选择媒体" : "选择图片", true); choose.setOnClickListener(v -> chooseFile(slot, video));
        actions.addView(choose, new LinearLayout.LayoutParams(0, dp(46), 1f));
        Button reset = button("恢复默认", false); reset.setOnClickListener(v -> reset(slot));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(108), dp(46)); rp.leftMargin = dp(10); actions.addView(reset, rp);
        LinearLayout.LayoutParams ap = match(); ap.topMargin = dp(14); box.addView(actions, ap);

        TextView opacityLabel = text("透明度 · " + prefs.getInt(BackgroundContract.OPACITY_PREFIX + slot, 100) + "%", 14, primary);
        LinearLayout.LayoutParams olp = wrap(); olp.topMargin = dp(16); box.addView(opacityLabel, olp);
        SeekBar opacity = new SeekBar(this); opacity.setMax(100); opacity.setProgress(prefs.getInt(BackgroundContract.OPACITY_PREFIX + slot, 100));
        opacity.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                opacityLabel.setText("透明度 · " + progress + "%");
                if (fromUser) prefs.edit().putInt(BackgroundContract.OPACITY_PREFIX + slot, progress).apply();
            }
        }); box.addView(opacity, match());

        Switch blur = new Switch(this); blur.setText("背景模糊"); blur.setTextColor(primary); blur.setTextSize(14);
        blur.setChecked(prefs.getBoolean(BackgroundContract.BLUR_ENABLED_PREFIX + slot, false));
        blur.setOnCheckedChangeListener((buttonView, isChecked) -> prefs.edit().putBoolean(BackgroundContract.BLUR_ENABLED_PREFIX + slot, isChecked).apply());
        LinearLayout.LayoutParams bp = match(); bp.topMargin = dp(4); box.addView(blur, bp);

        int radiusNow = prefs.getInt(BackgroundContract.BLUR_RADIUS_PREFIX + slot, 20);
        TextView blurLabel = text("模糊强度 · " + radiusNow, 13, secondary); box.addView(blurLabel);
        SeekBar radius = new SeekBar(this); radius.setMax(80); radius.setProgress(radiusNow);
        radius.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                blurLabel.setText("模糊强度 · " + progress);
                if (fromUser) prefs.edit().putInt(BackgroundContract.BLUR_RADIUS_PREFIX + slot, progress).apply();
            }
        }); box.addView(radius, match());
        addCard(parent, box); return status;
    }

    private void addFontCard(LinearLayout parent) {
        LinearLayout box = cardBox();
        TextView t = text("字体颜色", 20, primary); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); box.addView(t);
        TextView d = text("用于背景较亮或较暗时强制设置 Settings 文字颜色。切换后重新进入设置页面。", 13, secondary);
        LinearLayout.LayoutParams p = wrap(); p.topMargin = dp(4); box.addView(d, p);
        RadioGroup group = new RadioGroup(this); group.setOrientation(RadioGroup.VERTICAL);
        String[] names = {"跟随系统", "强制浅色文字", "强制深色文字"};
        int current = prefs.getInt(BackgroundContract.FONT_MODE, BackgroundContract.FONT_FOLLOW);
        for (int i = 0; i < names.length; i++) {
            RadioButton r = new RadioButton(this); r.setId(500 + i); r.setText(names[i]); r.setTextColor(primary); r.setTextSize(14); group.addView(r); if (i == current) r.setChecked(true);
        }
        group.setOnCheckedChangeListener((g, id) -> prefs.edit().putInt(BackgroundContract.FONT_MODE, Math.max(0, id - 500)).apply());
        LinearLayout.LayoutParams gp = match(); gp.topMargin = dp(8); box.addView(group, gp); addCard(parent, box);
    }


    private void addSettingsThemeModeCard(LinearLayout parent) {
        LinearLayout box = cardBox();
        TextView t = text("设置应用外观", 20, primary); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); box.addView(t);
        TextView d = text("单独控制 com.android.settings 使用浅色或深色主题。它通过 Settings 自己的日夜模式切换资源，不直接修改卡片，也不会改动上面的字体颜色配置。切换后请重新打开“设置”应用。", 13, secondary);
        LinearLayout.LayoutParams p = wrap(); p.topMargin = dp(4); box.addView(d, p);
        RadioGroup group = new RadioGroup(this); group.setOrientation(RadioGroup.VERTICAL);
        String[] names = {"跟随系统", "强制设置浅色", "强制设置深色"};
        int current = prefs.getInt(BackgroundContract.SETTINGS_THEME_MODE, BackgroundContract.SETTINGS_THEME_FOLLOW);
        for (int i = 0; i < names.length; i++) {
            RadioButton r = new RadioButton(this); r.setId(950 + i); r.setText(names[i]); r.setTextColor(primary); r.setTextSize(14); group.addView(r); if (i == current) r.setChecked(true);
        }
        group.setOnCheckedChangeListener((g, id) -> prefs.edit().putInt(BackgroundContract.SETTINGS_THEME_MODE, Math.max(0, id - 950)).apply());
        LinearLayout.LayoutParams gp = match(); gp.topMargin = dp(8); box.addView(group, gp);
        addCard(parent, box);
    }

    private void addThemeCard(LinearLayout parent) {
        LinearLayout box = cardBox();
        TextView t = text("模块外观", 20, primary); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); box.addView(t);
        TextView d = text("控制模块本体的明暗模式、Monet 主题色与自定义背景，不会修改系统主题。", 13, secondary);
        LinearLayout.LayoutParams p = wrap(); p.topMargin = dp(4); box.addView(d, p);

        TextView modeTitle = text("界面模式", 14, primary); LinearLayout.LayoutParams mt = wrap(); mt.topMargin = dp(14); box.addView(modeTitle, mt);
        RadioGroup modes = new RadioGroup(this); modes.setOrientation(RadioGroup.HORIZONTAL);
        String[] modeNames = {"跟随系统", "浅色", "深色"};
        int currentMode = prefs.getInt(BackgroundContract.UI_THEME_MODE, BackgroundContract.UI_THEME_FOLLOW);
        for (int i = 0; i < modeNames.length; i++) {
            RadioButton r = new RadioButton(this); r.setId(800 + i); r.setText(modeNames[i]); r.setTextColor(primary); r.setTextSize(13);
            modes.addView(r, new RadioGroup.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            if (i == currentMode) r.setChecked(true);
        }
        modes.setOnCheckedChangeListener((g, id) -> {
            int value = Math.max(0, id - 800);
            if (value != prefs.getInt(BackgroundContract.UI_THEME_MODE, BackgroundContract.UI_THEME_FOLLOW)) {
                prefs.edit().putInt(BackgroundContract.UI_THEME_MODE, value).apply();
                recreatePreservingScroll();
            }
        });
        box.addView(modes, match());

        Switch monet = new Switch(this); monet.setText("根据壁纸自动 Monet 取色"); monet.setTextColor(primary);
        monet.setChecked(prefs.getBoolean(BackgroundContract.UI_MONET, true));
        monet.setOnCheckedChangeListener((b, checked) -> {
            if (checked != prefs.getBoolean(BackgroundContract.UI_MONET, true)) {
                prefs.edit().putBoolean(BackgroundContract.UI_MONET, checked).apply();
                recreatePreservingScroll();
            }
        });
        LinearLayout.LayoutParams mp = match(); mp.topMargin = dp(8); box.addView(monet, mp);

        Button palette = button("可视化调色盘 / 自定义主题色", true);
        palette.setOnClickListener(v -> showPaletteDialog());
        LinearLayout.LayoutParams pp = match(); pp.topMargin = dp(8); box.addView(palette, pp);

        TextView bgTitle = text("模块自定义背景", 14, primary); LinearLayout.LayoutParams bt = wrap(); bt.topMargin = dp(16); box.addView(bgTitle, bt);
        uiBgStatus = text("跟随纯色背景", 13, accent); LinearLayout.LayoutParams us = wrap(); us.topMargin = dp(4); box.addView(uiBgStatus, us);
        LinearLayout bgActions = new LinearLayout(this); bgActions.setOrientation(LinearLayout.HORIZONTAL);
        Button chooseBg = button("选择背景", true); chooseBg.setOnClickListener(v -> chooseUiBackground());
        bgActions.addView(chooseBg, new LinearLayout.LayoutParams(0, dp(46), 1f));
        Button clearBg = button("清除", false); clearBg.setOnClickListener(v -> clearUiBackground());
        LinearLayout.LayoutParams cbp = new LinearLayout.LayoutParams(dp(96), dp(46)); cbp.leftMargin = dp(10); bgActions.addView(clearBg, cbp);
        LinearLayout.LayoutParams bap = match(); bap.topMargin = dp(10); box.addView(bgActions, bap);

        int opacityNow = prefs.getInt(BackgroundContract.UI_BG_OPACITY, 100);
        TextView opacityLabel = text("背景透明度 · " + opacityNow + "%", 13, primary); LinearLayout.LayoutParams uop = wrap(); uop.topMargin = dp(12); box.addView(opacityLabel, uop);
        SeekBar opacity = new SeekBar(this); opacity.setMax(100); opacity.setProgress(opacityNow);
        opacity.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                opacityLabel.setText("背景透明度 · " + progress + "%");
                if (fromUser) prefs.edit().putInt(BackgroundContract.UI_BG_OPACITY, progress).apply();
            }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { recreatePreservingScroll(); }
        }); box.addView(opacity, match());

        Switch uiBlur = new Switch(this); uiBlur.setText("模块背景模糊"); uiBlur.setTextColor(primary); uiBlur.setTextSize(14);
        uiBlur.setChecked(prefs.getBoolean(BackgroundContract.UI_BG_BLUR_ENABLED, false));
        uiBlur.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(BackgroundContract.UI_BG_BLUR_ENABLED, isChecked).apply();
            recreatePreservingScroll();
        });
        box.addView(uiBlur, match());

        int blurNow = prefs.getInt(BackgroundContract.UI_BG_BLUR_RADIUS, 20);
        TextView blurLabel = text("模块模糊强度 · " + blurNow, 13, secondary); box.addView(blurLabel);
        SeekBar blur = new SeekBar(this); blur.setMax(80); blur.setProgress(blurNow);
        blur.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                blurLabel.setText("模块模糊强度 · " + progress);
                if (fromUser) prefs.edit().putInt(BackgroundContract.UI_BG_BLUR_RADIUS, progress).apply();
            }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { recreatePreservingScroll(); }
        }); box.addView(blur, match());

        addCard(parent, box);
    }

    private void addAuthorCard(LinearLayout parent) {
        LinearLayout box = cardBox();
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);

        ImageView avatar = new ImageView(this);
        avatar.setImageResource(com.ciallo.hyperbackground.R.drawable.app_icon);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setBackground(rounded(darkUi ? Color.rgb(45,45,50) : Color.rgb(245,245,248), 18));
        avatar.setPadding(dp(3), dp(3), dp(3), dp(3));
        row.addView(avatar, new LinearLayout.LayoutParams(dp(64), dp(64)));

        LinearLayout textCol = new LinearLayout(this); textCol.setOrientation(LinearLayout.VERTICAL);
        TextView t = text("制作者 · 苍簇", 19, primary); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); textCol.addView(t);
        TextView d = text("HyperBackground", 13, secondary); LinearLayout.LayoutParams dlp = wrap(); dlp.topMargin = dp(3); textCol.addView(d, dlp);
        LinearLayout.LayoutParams tcp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); tcp.leftMargin = dp(14); row.addView(textCol, tcp);
        box.addView(row, match());

        LinearLayout links = new LinearLayout(this); links.setOrientation(LinearLayout.HORIZONTAL);
        Button coolapk = button("酷安主页  ↗", false);
        coolapk.setOnClickListener(v -> openUrl("https://www.coolapk.com/u/18795532"));
        links.addView(coolapk, new LinearLayout.LayoutParams(0, dp(46), 1f));

        Button github = button("GitHub  ↗", false);
        try {
            Drawable gh = getDrawable(com.ciallo.hyperbackground.R.drawable.ic_github);
            if (gh != null) { gh.setTint(primary); github.setCompoundDrawablesWithIntrinsicBounds(gh, null, null, null); github.setCompoundDrawablePadding(dp(7)); }
        } catch (Throwable ignored) {}
        github.setOnClickListener(v -> openUrl("https://github.com/Solomonstery/HyperBackground"));
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(0, dp(46), 1f); gp.leftMargin = dp(10); links.addView(github, gp);
        LinearLayout.LayoutParams lp = match(); lp.topMargin = dp(14); box.addView(links, lp);
        addCard(parent, box);
    }

    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Throwable e) { Toast.makeText(this, "无法打开链接", Toast.LENGTH_SHORT).show(); }
    }

    private void showPaletteDialog() {
        final int initial = prefs.getInt(BackgroundContract.UI_ACCENT, accent);
        final float[] hsv = new float[3]; Color.colorToHSV(initial, hsv);
        final boolean[] internal = {false};

        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(20), dp(8), dp(20), 0);
        final View preview = new View(this); preview.setBackground(rounded(initial, 18)); panel.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72)));

        final EditText hex = new EditText(this); hex.setSingleLine(true); hex.setText(String.format("#%06X", 0xFFFFFF & initial)); hex.setHint("#RRGGBB"); hex.setTextColor(initial);
        LinearLayout.LayoutParams hp = match(); hp.topMargin = dp(12); panel.addView(hex, hp);

        TextView hueLabel = text("色相 · " + Math.round(hsv[0]) + "°", 13, initial); LinearLayout.LayoutParams hlp = wrap(); hlp.topMargin = dp(12); panel.addView(hueLabel, hlp);
        SeekBar hue = new SeekBar(this); hue.setMax(360); hue.setProgress(Math.round(hsv[0])); panel.addView(hue, match());
        TextView satLabel = text("饱和度 · " + Math.round(hsv[1] * 100f) + "%", 13, initial); panel.addView(satLabel);
        SeekBar sat = new SeekBar(this); sat.setMax(100); sat.setProgress(Math.round(hsv[1] * 100f)); panel.addView(sat, match());
        TextView valueLabel = text("明度 · " + Math.round(hsv[2] * 100f) + "%", 13, initial); panel.addView(valueLabel);
        SeekBar value = new SeekBar(this); value.setMax(100); value.setProgress(Math.round(hsv[2] * 100f)); panel.addView(value, match());

        LinearLayout swatches = new LinearLayout(this); swatches.setOrientation(LinearLayout.HORIZONTAL);
        int[] presets = {0xFF7C8CFF, 0xFF5E8BFF, 0xFF45B6FE, 0xFF36C9A7, 0xFF7EC855, 0xFFFFB84D, 0xFFFF7A59, 0xFFFF6B9A};
        for (int c : presets) {
            View dot = new View(this); dot.setBackground(rounded(c, 14));
            LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(0, dp(34), 1f); dp1.rightMargin = dp(6); swatches.addView(dot, dp1);
            dot.setOnClickListener(v -> {
                Color.colorToHSV(c, hsv); internal[0] = true;
                hue.setProgress(Math.round(hsv[0])); sat.setProgress(Math.round(hsv[1] * 100f)); value.setProgress(Math.round(hsv[2] * 100f));
                internal[0] = false; updatePaletteViews(hsv, preview, hex, hueLabel, satLabel, valueLabel, null, null, internal);
            });
        }
        LinearLayout.LayoutParams swp = match(); swp.topMargin = dp(10); panel.addView(swatches, swp);

        final AlertDialog[] holder = new AlertDialog[1];
        final Runnable update = () -> {
            if (internal[0]) return;
            hsv[0] = hue.getProgress(); hsv[1] = sat.getProgress() / 100f; hsv[2] = value.getProgress() / 100f;
            updatePaletteViews(hsv, preview, hex, hueLabel, satLabel, valueLabel,
                    holder[0] == null ? null : holder[0].getButton(AlertDialog.BUTTON_POSITIVE),
                    holder[0] == null ? null : holder[0].getButton(AlertDialog.BUTTON_NEGATIVE), internal);
        };
        SimpleSeek listener = new SimpleSeek() { @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { if (fromUser) update.run(); } };
        hue.setOnSeekBarChangeListener(listener); sat.setOnSeekBarChangeListener(listener); value.setOnSeekBarChangeListener(listener);

        hex.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                if (internal[0]) return;
                try {
                    int c = Color.parseColor(s.toString().trim());
                    Color.colorToHSV(c, hsv); internal[0] = true;
                    hue.setProgress(Math.round(hsv[0])); sat.setProgress(Math.round(hsv[1] * 100f)); value.setProgress(Math.round(hsv[2] * 100f));
                    internal[0] = false;
                    preview.setBackground(rounded(c, 18)); hex.setTextColor(c); hueLabel.setTextColor(c); satLabel.setTextColor(c); valueLabel.setTextColor(c);
                    if (holder[0] != null) { holder[0].getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(c); holder[0].getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(c); }
                } catch (Throwable ignored) {}
            }
        });

        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("可视化主题色").setView(panel)
                .setNegativeButton("取消", null)
                .setPositiveButton("应用", null).create();
        holder[0] = dialog;
        dialog.setOnShowListener(x -> {
            update.run();
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                try {
                    int c = Color.parseColor(hex.getText().toString().trim());
                    prefs.edit().putInt(BackgroundContract.UI_ACCENT, c).putBoolean(BackgroundContract.UI_MONET, false).apply();
                    dialog.dismiss();
                    recreatePreservingScroll();
                } catch (Throwable e) { Toast.makeText(this, "颜色格式无效，例如 #7C8CFF", Toast.LENGTH_LONG).show(); }
            });
        });
        dialog.show();
    }

    private void updatePaletteViews(float[] hsv, View preview, EditText hex, TextView hueLabel, TextView satLabel,
                                    TextView valueLabel, Button positive, Button negative, boolean[] internal) {
        int c = Color.HSVToColor(hsv);
        preview.setBackground(rounded(c, 18));
        internal[0] = true; hex.setText(String.format("#%06X", 0xFFFFFF & c)); hex.setSelection(hex.getText().length()); internal[0] = false;
        hex.setTextColor(c); hueLabel.setTextColor(c); satLabel.setTextColor(c); valueLabel.setTextColor(c);
        hueLabel.setText("色相 · " + Math.round(hsv[0]) + "°"); satLabel.setText("饱和度 · " + Math.round(hsv[1] * 100f) + "%"); valueLabel.setText("明度 · " + Math.round(hsv[2] * 100f) + "%");
        if (positive != null) positive.setTextColor(c); if (negative != null) negative.setTextColor(c);
    }

    private void chooseUiBackground() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivityForResult(i, REQUEST_UI_BACKGROUND);
    }

    private void clearUiBackground() {
        File f = new File(getFilesDir(), "ui_background.bin");
        if (f.exists() && !f.delete()) { Toast.makeText(this, "清除失败", Toast.LENGTH_SHORT).show(); return; }
        prefs.edit().remove(BackgroundContract.UI_BG_MIME).apply();
        recreatePreservingScroll();
    }

    private void chooseFile(String slot, boolean video) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE);
        if (video) { i.setType("*/*"); i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/mp4", "video/webm"}); } else i.setType("image/*");
        int request = BackgroundContract.HOME.equals(slot) ? REQUEST_HOME : REQUEST_DEVICE;
        startActivityForResult(i, request);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData(); String mime = getContentResolver().getType(uri); if (mime == null) mime = "application/octet-stream";

        if (requestCode == REQUEST_UI_BACKGROUND) {
            if (!mime.startsWith("image/")) { Toast.makeText(this, "模块背景仅支持图片/GIF/WebP", Toast.LENGTH_LONG).show(); return; }
            try {
                saveUiBackground(uri, mime);
                Toast.makeText(this, "模块背景已保存", Toast.LENGTH_SHORT).show();
                recreatePreservingScroll();
            } catch (Throwable error) { Toast.makeText(this, "保存失败：" + error.getMessage(), Toast.LENGTH_LONG).show(); }
            return;
        }

        String slot = requestCode == REQUEST_HOME ? BackgroundContract.HOME : requestCode == REQUEST_DEVICE ? BackgroundContract.DEVICE : null;
        if (slot == null) return;
        boolean device = BackgroundContract.DEVICE.equals(slot);
        if (!mime.startsWith("image/") && !(device && mime.startsWith("video/"))) { Toast.makeText(this, "不支持这种文件类型：" + mime, Toast.LENGTH_LONG).show(); return; }
        try { save(slot, uri, mime); Toast.makeText(this, "已保存；重新进入对应设置页面后生效", Toast.LENGTH_SHORT).show(); refreshStatus(); }
        catch (Throwable error) { Toast.makeText(this, "保存失败：" + error.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void saveUiBackground(Uri uri, String mime) throws Exception {
        saveFileTo(new File(getFilesDir(), "ui_background.bin"), uri);
        prefs.edit().putString(BackgroundContract.UI_BG_MIME, mime).apply();
    }

    private void save(String slot, Uri uri, String mime) throws Exception {
        File dir = new File(getFilesDir(), "backgrounds"); if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("无法创建目录");
        File target = new File(dir, slot + ".bin"); saveFileTo(target, uri); target.setLastModified(System.currentTimeMillis());
        prefs.edit().putString(BackgroundContract.MIME_PREFIX + slot, mime).apply();
    }

    private void saveFileTo(File target, Uri uri) throws Exception {
        File dir = target.getParentFile(); if (dir != null && !dir.exists() && !dir.mkdirs()) throw new IllegalStateException("无法创建目录");
        File temp = new File(target.getAbsolutePath() + ".tmp"); if (temp.exists() && !temp.delete()) throw new IllegalStateException("无法覆盖临时文件");
        long total = 0; byte[] buffer = new byte[65536]; InputStream in = null; FileOutputStream out = null;
        try {
            in = getContentResolver().openInputStream(uri); if (in == null) throw new IllegalStateException("无法读取文件");
            out = new FileOutputStream(temp); int n;
            while ((n = in.read(buffer)) != -1) { total += n; if (total > MAX_FILE_SIZE) throw new IllegalArgumentException("文件不能超过 200 MB"); out.write(buffer, 0, n); }
            out.getFD().sync();
        } finally { if (in != null) in.close(); if (out != null) out.close(); }
        if (target.exists() && !target.delete()) throw new IllegalStateException("无法覆盖旧背景");
        if (!temp.renameTo(target)) throw new IllegalStateException("无法完成文件替换");
    }

    private void reset(String slot) {
        File f = new File(new File(getFilesDir(), "backgrounds"), slot + ".bin");
        if (f.exists() && !f.delete()) { Toast.makeText(this, "恢复失败", Toast.LENGTH_SHORT).show(); return; }
        prefs.edit().remove(BackgroundContract.MIME_PREFIX + slot).apply(); refreshStatus(); Toast.makeText(this, "已恢复系统默认", Toast.LENGTH_SHORT).show();
    }

    private void refreshStatus() {
        updateStatus(homeStatus, BackgroundContract.HOME); updateStatus(deviceStatus, BackgroundContract.DEVICE);
        if (uiBgStatus != null) {
            File f = new File(getFilesDir(), "ui_background.bin");
            uiBgStatus.setText(f.isFile() ? "已启用 · " + prefs.getString(BackgroundContract.UI_BG_MIME, "image/*") + " · " + humanSize(f.length()) : "跟随纯色背景");
        }
    }

    private void updateStatus(TextView v, String slot) {
        if (v == null) return; File f = new File(new File(getFilesDir(), "backgrounds"), slot + ".bin");
        if (!f.isFile()) { v.setText("跟随系统默认"); return; }
        String mime = prefs.getString(BackgroundContract.MIME_PREFIX + slot, "未知类型"); v.setText("已启用 · " + mime + " · " + humanSize(f.length()));
    }

    private void recreatePreservingScroll() {
        int y = mainScroll == null ? 0 : mainScroll.getScrollY();
        prefs.edit().putInt(BackgroundContract.UI_SCROLL_Y, y).apply();
        recreate();
    }

    private static String humanSize(long b) { if (b >= 1048576L) return String.format("%.1f MB", b / 1048576f); if (b >= 1024L) return String.format("%.1f KB", b / 1024f); return b + " B"; }

    private LinearLayout cardBox() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(18), dp(18), dp(18), dp(18));
        int base = card;
        if (new File(getFilesDir(), "ui_background.bin").isFile()) base = withAlpha(card, darkUi ? 232 : 238);
        l.setBackground(rounded(base, 22)); l.setElevation(dp(1)); return l;
    }
    private void addCard(LinearLayout parent, LinearLayout box) { LinearLayout.LayoutParams p = match(); p.bottomMargin = dp(14); parent.addView(box, p); }
    private TextView text(String s, int sp, int color) { TextView v = new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color); v.setLineSpacing(0, 1.12f); return v; }
    private Button button(String label, boolean accentButton) {
        Button b = new Button(this); b.setText(label); b.setTextSize(14); b.setAllCaps(false); b.setGravity(Gravity.CENTER);
        b.setTextColor(accentButton ? bestTextColor(accent) : primary);
        b.setBackground(rounded(accentButton ? accent : (darkUi ? Color.rgb(48,49,54) : Color.rgb(238,239,244)), 15));
        b.setPadding(dp(12), 0, dp(12), 0); return b;
    }
    private GradientDrawable rounded(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private LinearLayout.LayoutParams wrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams match() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private static int withAlpha(int color, int alpha) { return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color)); }
    private static int bestTextColor(int color) { return Color.luminance(color) > 0.55 ? Color.BLACK : Color.WHITE; }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar seekBar) {}
        @Override public void onStopTrackingTouch(SeekBar seekBar) {}
    }
}

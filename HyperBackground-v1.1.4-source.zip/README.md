# HyperBackground 1.1.4

面向 HyperOS 4 / Android 17 设置应用的 LSPosed 背景自定义模块。

## 1.1.4

- 删除 1.1.3 中“直接修改卡片 View 背景色”的实现。
- 新增“设置应用外观”：跟随系统 / 强制设置浅色 / 强制设置深色。
- 该功能通过 `com.android.settings` Activity 的 `Configuration.uiMode` 切换 Settings 自己的日夜主题资源，不再手工染卡片。
- “设置应用外观”与“字体颜色”是两套独立配置：前者控制 Settings 的主题模式，后者仍只负责文字颜色 Hook。
- 切换设置应用外观后，重新打开“设置”应用生效。
- 保留设置主页与“我的设备”两套独立背景、透明度、模糊功能。
- 保留模块本体浅色/深色/跟随系统、自定义背景、Monet 与可视化调色盘。

## 版本

- versionName: `1.1.4`
- versionCode: `5`

## 作者

苍簇

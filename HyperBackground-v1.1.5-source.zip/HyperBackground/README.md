# HyperBackground 1.1.3

HyperOS 设置背景自定义 LSPosed 模块。

## 1.1.3

- 保留设置主页与“我的设备”两个独立背景通道。
- 支持背景透明度与模糊控制。
- 支持模块界面主题与自定义背景。
- 新增“设置应用外观”：跟随系统 / 强制浅色 / 强制深色。
- “设置应用外观”通过 `Configuration.uiMode` 控制 `com.android.settings` 自身日夜主题，不直接修改卡片 View。
- 与原有文字颜色控制相互独立。
- 不包含 HyperOS Logo 自定义文字功能。

## 版本

- versionName: `1.1.3`
- versionCode: `4`

## 作者

苍簇

- 酷安：https://www.coolapk.com/u/18795532
- GitHub：https://github.com/Solomonstery/HyperBackground

## 1.1.5 更新

- 新增模块本体背景卡片透明度调节。
- 仅在模块自定义背景存在时生效，100% 为完全不透明。
- 统一版本信息为 versionName 1.1.5 / versionCode 6。

# HyperBackground 1.1.5

HyperOS 设置背景与外观自定义 LSPosed 模块。

## 1.1.5 更新

- 保留设置主页与“我的设备”两个独立背景通道。
- 保留“设置应用外观”：跟随系统 / 强制浅色 / 强制深色。
- 新增 **设置卡片透明度** 调节，仅作用于 `com.android.settings` 内的卡片背景 Drawable。
- 卡片透明度不会让卡片内部文字、图标一起变透明。
- 100% 为原生卡片不透明效果；降低数值后可让自定义背景透过 Settings 卡片显示。
- Settings 页面刷新或重新绑定卡片背景时会重新应用透明度。
- 保留持续字体颜色 Hook，避免 MIUIX / Preference 刷新后覆盖强制字体颜色。
- 模块本体卡片保持原样，不再提供“模块卡片透明度”这一错误功能。

## 版本

- versionName: `1.1.5`
- versionCode: `6`

## 说明

- 设置卡片透明度目前作用于 `com.android.settings`。
- 卡片识别优先依据 CardView 类型和资源 ID 中的 card 结构名称，不会直接给整张 View 设置 alpha。
- 调节的是卡片背景 Drawable 的 alpha，因此卡片内容保持正常可读。

## 作者

苍簇

- 酷安：https://www.coolapk.com/u/18795532
- GitHub：https://github.com/Solomonstery/HyperBackground

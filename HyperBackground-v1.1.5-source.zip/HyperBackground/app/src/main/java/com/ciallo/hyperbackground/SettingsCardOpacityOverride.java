package com.ciallo.hyperbackground;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;

import java.util.Locale;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/** Applies user-selected alpha only to Settings card backgrounds, never to card contents. */
final class SettingsCardOpacityOverride {
    private static final ThreadLocal<Boolean> INTERNAL = new ThreadLocal<>();

    private SettingsCardOpacityOverride() {}

    static void install() {
        hookBackgroundSetter("setBackground", Drawable.class);
        hookBackgroundSetter("setBackgroundDrawable", Drawable.class);

        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    if (!(param.thisObject instanceof Activity)) return;
                    Activity activity = (Activity) param.thisObject;
                    if (!isSettings(activity)) return;
                    View root = activity.getWindow() == null ? null : activity.getWindow().getDecorView();
                    if (root == null) return;
                    root.post(() -> applyTree(root));
                    root.postDelayed(() -> applyTree(root), 180L);
                }
            });
        } catch (Throwable error) {
            XposedBridge.log("[HyperBackground] Could not hook Activity.onResume for Settings card opacity: " + error);
            XposedBridge.log(error);
        }
    }

    private static void hookBackgroundSetter(String method, Class<?> argType) {
        try {
            XposedHelpers.findAndHookMethod(View.class, method, argType, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    if (Boolean.TRUE.equals(INTERNAL.get()) || !(param.thisObject instanceof View)) return;
                    View view = (View) param.thisObject;
                    if (!isSettings(view.getContext()) || !isCardSurface(view)) return;
                    applyBackgroundAlpha(view);
                }
            });
        } catch (Throwable error) {
            XposedBridge.log("[HyperBackground] Could not hook View." + method + " for Settings card opacity: " + error);
            XposedBridge.log(error);
        }
    }

    private static void applyTree(View view) {
        if (view == null || !isSettings(view.getContext())) return;
        if (isCardSurface(view)) applyBackgroundAlpha(view);
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) applyTree(group.getChildAt(i));
        }
    }

    private static void applyBackgroundAlpha(View view) {
        try {
            int percent = readOpacity(view.getContext());
            Drawable background = view.getBackground();
            if (background == null) return;
            Drawable target = background.mutate();
            target.setAlpha(Math.round(255f * percent / 100f));
            view.invalidate();
        } catch (Throwable ignored) {}
    }

    private static int readOpacity(Context context) {
        try {
            return BackgroundContract.query(context, BackgroundContract.HOME).settingsCardOpacity;
        } catch (Throwable ignored) {
            return 100;
        }
    }

    private static boolean isSettings(Context context) {
        return context != null && "com.android.settings".equals(context.getPackageName());
    }

    private static boolean isCardSurface(View view) {
        if (!(view instanceof ViewGroup)) return false;

        String className = view.getClass().getName().toLowerCase(Locale.ROOT);
        if (className.contains("cardview") || className.contains("materialcard") || className.endsWith("card")) {
            return true;
        }

        int id = view.getId();
        if (id == View.NO_ID) return false;
        try {
            String name = view.getResources().getResourceEntryName(id).toLowerCase(Locale.ROOT);
            if (!name.contains("card")) return false;
            if (name.contains("icon") || name.contains("title") || name.contains("summary")
                    || name.contains("text") || name.contains("image") || name.contains("logo")
                    || name.contains("button") || name.contains("switch") || name.contains("indicator")) {
                return false;
            }
            return name.contains("card_view") || name.contains("cardview") || name.contains("card_layout")
                    || name.contains("card_container") || name.contains("card_bg") || name.contains("card_background")
                    || name.startsWith("card_") || name.endsWith("_card") || name.equals("card");
        } catch (Throwable ignored) {
            return false;
        }
    }
}

# HyperBackground 1.2.0

面向 HyperOS 的 LSPosed 设置背景与外观自定义模块。

## 1.2.0 更新

- 新增 **全局背景** 通道。
- 全局背景覆盖 `com.android.settings` 中除“设置主页”和“我的设备”之外的页面。
- 根据手机管家 APK 补充 `com.miui.securitymanager` / `com.miui.securitycenter` 作用域，让由手机管家提供的设置页面也能读取同一张全局背景。
- 全局背景拥有自己独立的图片、透明度、模糊开关和模糊强度。
- 设置主页继续使用 `home` 独立通道。
- “我的设备”继续使用 `device` 独立通道，并在进入该 Fragment 时主动撤下全局层，避免全局背景覆盖独立背景。
- 保留 1.1.4 的持续字体颜色 Hook 与“设置应用外观”功能，不把字体强制扩展到手机管家，避免改变既有行为。

## 三个背景通道

1. **设置主页**：仅 `com.android.settings.MiuiSettings`。
2. **我的设备**：仅 `com.android.settings.device.MiuiMyDeviceSettings`。
3. **全局背景**：其他 Settings Activity + 手机管家相关 Activity。

优先级：**我的设备 / 设置主页 > 全局背景**。

## 全局背景说明

手机管家版本之间 Activity 和布局差异较大。1.2.0 不修改手机管家功能逻辑，只在它的 Activity 内容层后方插入背景，并清除常见的全屏容器背景。卡片、文字、按钮等控件仍由原应用自己绘制。

## 其他功能

- 首页 / 我的设备独立背景
- 图片 / GIF / 动态 WebP；“我的设备”支持 MP4 / WebM
- 三通道独立透明度和模糊
- Settings 字体颜色：跟随系统 / 强制浅色 / 强制深色
- Settings 应用外观：跟随系统 / 强制浅色 / 强制深色
- 模块本体浅色 / 深色 / 跟随系统
- 模块本体自定义背景、透明度与模糊
- Monet 壁纸取色 + HSV 可视化调色盘
- 作者：苍簇

## LSPosed 作用域

- `com.android.settings`
- `com.miui.securitymanager`
- `com.miui.securitycenter`

如果设备上只存在其中一个手机管家包名，只勾选实际存在的那个即可。

## 构建

- `versionName = 1.2.0`
- `versionCode = 7`
- Java 17
- Android SDK 35
- Build Tools 35.0.1

输出：`dist/HyperBackground-v1.2.0.apk`

## 作者

**苍簇**  
酷安：https://www.coolapk.com/u/18795532  
GitHub：https://github.com/Solomonstery/HyperBackground

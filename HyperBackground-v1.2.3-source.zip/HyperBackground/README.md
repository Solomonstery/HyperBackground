# HyperBackground 1.2.3

HyperOS 设置背景与外观自定义 LSPosed 模块。

## 1.2.3 更新

- 修复手机管家页面顶部大面积黑色/半透明遮罩：对 `com.miui.securitymanager` / `com.miui.securitycenter` 的顶部页面级 Surface 使用更精确的透明化规则，同时保留卡片、按钮、开关等控件背景。
- 新增权限/授权/确认类 Activity 黑名单。权限确认、CTA、临时 Dialog、透明跳板页默认不应用全局背景，避免安全弹窗后方出现突兀壁纸。
- 新增“小米设置”扩展：`com.xiaomi.misettings`，覆盖健康使用手机、屏幕时间等系统设置扩展页。
- 新增“设备互联”扩展：`com.milink.service`，仅处理设备互联/连接设置相关 Activity，不影响配对弹窗、权限页和其他服务 UI。
- 新增“系统桌面设置”扩展：`com.miui.home`，仅处理桌面设置、抽屉设置、手势/导航设置 Activity，不修改 Launcher/最近任务本体。
- 新增“主题壁纸设置”扩展：`com.android.thememanager`，只处理由系统设置入口进入的主题/壁纸设置 Activity，不修改主题商店主界面。
- 增加 `com.android.phone` 的移动网络设置兼容规则，仅匹配 MobileNetwork / Cellular / SIM Settings 类页面。
- 保留 1.2.2 的 `setContentView()` 后重新挂载机制，避免 Activity 重建布局后丢失背景。

## 背景通道

1. `home`：设置主页
2. `device`：我的设备
3. `global`：其他受支持的系统设置与扩展页面

优先级仍为：**我的设备 / 设置主页 > 全局背景**。

## 当前全局背景作用域

- `com.android.settings`
- `com.miui.securitymanager`
- `com.miui.securitycenter`
- `com.xiaomi.misettings`
- `com.milink.service`
- `com.miui.home`
- `com.android.thememanager`
- `com.android.phone`

其中桌面、主题、设备互联、移动网络均使用 Activity 白名单/特征匹配，避免整个应用被全局背景接管。

## 权限页保护

以下类型默认跳过全局背景：

- Permission / RequirePermission
- Authorization / Authorize
- AccessCheck
- Confirm / Grant
- CTA
- Dialog / Transparent 临时 Activity

目的是保持权限与安全确认界面的原生可读性。

## 其他功能

- 设置主页独立背景
- “我的设备”独立图片 / GIF / 动态 WebP / MP4 / WebM 背景
- 全局背景独立透明度与模糊
- 设置 App 独立浅色 / 深色模式
- 持续强制文字浅色 / 深色
- 模块本体自定义背景
- Monet 壁纸取色与 HSV 可视化调色盘

## 版本

- `versionName = 1.2.3`
- `versionCode = 10`

## 作者

**苍簇**

- 酷安：https://www.coolapk.com/u/18795532
- GitHub：https://github.com/Solomonstery/HyperBackground

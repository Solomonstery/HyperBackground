# HyperBackground 1.2.3

面向 HyperOS 4 / Android 17 设置应用的 LSPosed 背景与外观自定义模块。

## 1.2.3 更新

本版本主要做兼容范围收敛，不再保留已经确认无法稳定适配的跨包页面，避免出现“部分页面有背景、部分页面纯黑”这种不完整效果。

- 保留 `com.android.settings` 的主页 / 我的设备 / 全局三通道。
- 保留已验证可用的设备互联扩展：`com.milink.service`。
- 移除手机管家相关作用域与兼容代码：`com.miui.securitymanager` / `com.miui.securitycenter`。
- 移除小米设置、系统桌面、主题壁纸、移动网络扩展作用域与对应兼容代码。
- 移除针对这些失败扩展包的 Surface 清理、Flutter 透明宿主等实验逻辑。
- 权限 / 授权 / 临时确认页面仍保持原生，不套全局背景。
- 不修改现有主页背景、我的设备背景、Settings 全局背景、字体强制、Settings 独立深浅模式、模块主题等已工作的功能。

## 当前作用域

```text
com.android.settings
com.milink.service
```

## 背景通道

1. `home`：设置主页
2. `device`：我的设备
3. `global`：其他 Settings 页面，以及已验证可用的设备互联设置页

优先级：

```text
我的设备 > 设置主页 > 全局背景
```

## 主要功能

- 设置主页独立背景
- 我的设备独立背景
- 普通 Settings 页面全局背景
- 设备互联设置页全局背景
- 图片透明度与模糊
- 持续强制文字深色 / 浅色
- 单独控制 `com.android.settings` 跟随系统 / 强制浅色 / 强制深色
- 模块本体浅色 / 深色 / 跟随系统
- 模块本体自定义背景
- Monet 壁纸取色
- 可视化 HSV 调色盘

## 文件支持

- 设置主页：JPG / PNG / WebP / GIF
- 我的设备：JPG / PNG / WebP / GIF / 动态 WebP / 无声循环 MP4 / WebM
- 全局背景：JPG / PNG / WebP / GIF

## 版本

- `versionName = 1.2.3`
- `versionCode = 10`

## 构建

源码包命名：

```text
HyperBackground-vX.Y.Z-source.zip
```

GitHub Actions 会选择版本号最高的源码包，检查 ZIP、APK 实际版本和固定签名后生成 Artifact 与 Release。

## 作者

**苍簇**

- 酷安：https://www.coolapk.com/u/18795532
- GitHub：https://github.com/Solomonstery/HyperBackground

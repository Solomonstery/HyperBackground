# HyperBackground

HyperOS 设置背景与外观自定义 LSPosed 模块。

> 当前开发版本：**1.3.0**  
> UI 架构：**Kotlin + Jetpack Compose + Miuix KMP**  
> Hook 核心：沿用 1.2.3 已验证逻辑

## 1.3.0

这是一次配置界面的大重构，视觉和交互路线参考 KernelSU Manager 当前的 MIUIX 实现。

- 配置 Activity 从 Java View 手写界面迁移为 Kotlin `ComponentActivity` + Compose。
- 使用 `top.yukonga.miuix.kmp` 的 `MiuixTheme`、`Scaffold`、`TopAppBar`、`Card`、`Slider`、`TabRow`、`SwitchPreference` 等组件。
- 浅色 / 深色 / 跟随系统统一由 `ThemeController` 管理。
- Monet 壁纸取色和自定义主题色继续保留，并直接驱动 MIUIX 主题。
- 设置主页 / 我的设备 / 全局背景三通道重新组织为 MIUIX 卡片。
- 保留媒体选择、透明度、模糊开关和模糊强度。
- “设置应用外观”和“文字颜色”继续保持两套独立配置。
- 模块自身自定义背景、透明度、模糊继续保留。
- 作者卡保留苍簇、酷安和 GitHub 入口。
- 固定签名文件继续沿用，避免升级安装时签名变化。
- Xposed Hook / Provider / BackgroundApplier 等稳定核心没有随 UI 重构改写。

## 当前作用域

- `com.android.settings`
- `com.milink.service`

## 背景通道

1. `home`：设置主页
2. `device`：我的设备
3. `global`：普通 Settings 页面及已验证的设备互联页面

## 构建

1. Java 17
2. Android SDK 35
3. Gradle 9.7
4. AGP 9.3.1
5. Kotlin 2.4.10
6. Compose BOM 2026.08.00
7. Miuix KMP 0.9.3

运行：

```bash
./build.sh
```

`build.sh` 会在需要时下载 Gradle 发行版，然后执行 `:app:assembleRelease`。产物输出到：

```text
dist/HyperBackground-v1.3.0.apk
```

## 作者

**苍簇**

- 酷安：https://www.coolapk.com/u/18795532
- GitHub：https://github.com/Solomonstery/HyperBackground

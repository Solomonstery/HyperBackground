package com.ciallo.hyperbackground

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color as AndroidColor
import android.graphics.ImageDecoder
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.AnimatedImageDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BlurOn
import androidx.compose.material.icons.rounded.ColorLens
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Wallpaper
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.Slider
import top.yukonga.miuix.kmp.basic.TabRow
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.ColorSchemeMode
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.theme.ThemeController
import top.yukonga.miuix.kmp.utils.overScrollVertical
import top.yukonga.miuix.kmp.utils.scrollEndHaptic
import java.io.File
import java.io.FileOutputStream

class ConfigActivity : ComponentActivity() {
    private lateinit var prefs: SharedPreferences
    private var pendingSlot: String? = null
    private var pendingUiBackground = false
    private var revision by mutableIntStateOf(0)

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        try {
            val mime = contentResolver.getType(uri) ?: "application/octet-stream"
            if (pendingUiBackground) {
                pendingUiBackground = false
                if (!mime.startsWith("image/")) {
                    toast("模块背景仅支持图片 / GIF / WebP")
                    return@registerForActivityResult
                }
                saveFileTo(File(filesDir, "ui_background.bin"), uri)
                prefs.edit().putString(BackgroundContract.UI_BG_MIME, mime).apply()
                toast("模块背景已保存")
                revision++
                return@registerForActivityResult
            }
            val slot = pendingSlot.also { pendingSlot = null } ?: return@registerForActivityResult
            val allowVideo = slot == BackgroundContract.DEVICE
            if (!mime.startsWith("image/") && !(allowVideo && mime.startsWith("video/"))) {
                toast("不支持这种文件类型：$mime")
                return@registerForActivityResult
            }
            val dir = File(filesDir, "backgrounds").apply { mkdirs() }
            saveFileTo(File(dir, "$slot.bin"), uri)
            prefs.edit().putString(BackgroundContract.MIME_PREFIX + slot, mime).apply()
            toast("已保存；重新进入对应设置页面后生效")
            revision++
        } catch (t: Throwable) {
            toast("保存失败：${t.message ?: "未知错误"}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(BackgroundContract.PREFS, 0)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { HyperBackgroundApp() }
    }

    @Composable
    private fun HyperBackgroundApp() {
        var themeMode by remember { mutableIntStateOf(prefs.getInt(BackgroundContract.UI_THEME_MODE, BackgroundContract.UI_THEME_FOLLOW)) }
        var monet by remember { mutableStateOf(prefs.getBoolean(BackgroundContract.UI_MONET, true)) }
        var accent by remember { mutableIntStateOf(prefs.getInt(BackgroundContract.UI_ACCENT, 0xFF6980FF.toInt())) }
        val systemDark = isSystemInDarkTheme()
        val dark = themeMode == BackgroundContract.UI_THEME_DARK || (themeMode == BackgroundContract.UI_THEME_FOLLOW && systemDark)
        val mode = when {
            monet && themeMode == BackgroundContract.UI_THEME_LIGHT -> ColorSchemeMode.MonetLight
            monet && themeMode == BackgroundContract.UI_THEME_DARK -> ColorSchemeMode.MonetDark
            monet -> ColorSchemeMode.MonetSystem
            themeMode == BackgroundContract.UI_THEME_LIGHT -> ColorSchemeMode.Light
            themeMode == BackgroundContract.UI_THEME_DARK -> ColorSchemeMode.Dark
            else -> ColorSchemeMode.System
        }
        val controller = ThemeController(mode, keyColor = if (monet) null else Color(accent), isDark = dark)

        MiuixTheme(controller = controller) {
            LaunchedEffect(dark) {
                WindowInsetsControllerCompat(window, window.decorView).apply {
                    isAppearanceLightStatusBars = !dark
                    isAppearanceLightNavigationBars = !dark
                }
            }
            Box(Modifier.fillMaxSize()) {
                ModuleBackground(revision)
                MainScreen(
                    revision = revision,
                    themeMode = themeMode,
                    monet = monet,
                    accent = accent,
                    onThemeMode = {
                        themeMode = it
                        prefs.edit().putInt(BackgroundContract.UI_THEME_MODE, it).apply()
                    },
                    onMonet = {
                        monet = it
                        prefs.edit().putBoolean(BackgroundContract.UI_MONET, it).apply()
                    },
                    onAccent = {
                        accent = it
                        monet = false
                        prefs.edit().putInt(BackgroundContract.UI_ACCENT, it).putBoolean(BackgroundContract.UI_MONET, false).apply()
                    }
                )
            }
        }
    }

    @Composable
    private fun ModuleBackground(revision: Int) {
        val file = remember(revision) { File(filesDir, "ui_background.bin") }
        if (!file.isFile) return
        val opacity = prefs.getInt(BackgroundContract.UI_BG_OPACITY, 100) / 100f
        val blurEnabled = prefs.getBoolean(BackgroundContract.UI_BG_BLUR_ENABLED, false)
        val blurRadius = prefs.getInt(BackgroundContract.UI_BG_BLUR_RADIUS, 20).toFloat()
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                ImageView(ctx).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    alpha = opacity
                    try {
                        val drawable = ImageDecoder.decodeDrawable(ImageDecoder.createSource(file))
                        setImageDrawable(drawable)
                        if (drawable is AnimatedImageDrawable) drawable.start()
                        if (Build.VERSION.SDK_INT >= 31 && blurEnabled && blurRadius > 0f) {
                            setRenderEffect(RenderEffect.createBlurEffect(blurRadius, blurRadius, Shader.TileMode.CLAMP))
                        }
                    } catch (_: Throwable) {}
                }
            }
        )
    }

    @Composable
    private fun MainScreen(
        revision: Int,
        themeMode: Int,
        monet: Boolean,
        accent: Int,
        onThemeMode: (Int) -> Unit,
        onMonet: (Boolean) -> Unit,
        onAccent: (Int) -> Unit,
    ) {
        val scrollBehavior = MiuixScrollBehavior()
        Scaffold(
            topBar = {
                TopAppBar(
                    title = "HyperBackground",
                    scrollBehavior = scrollBehavior,
                )
            },
            popupHost = { },
            contentWindowInsets = WindowInsets.systemBars
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxHeight()
                    .nestedScroll(scrollBehavior.nestedScrollConnection)
                    .scrollEndHaptic()
                    .overScrollVertical()
                    .padding(horizontal = 12.dp),
                contentPadding = innerPadding,
                overscrollEffect = null,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Spacer(Modifier.height(10.dp))
                    HeroCard()
                }
                item { BackgroundCard(BackgroundContract.HOME, "设置主页", "独立控制 HyperOS 设置首页", Icons.Rounded.Home, false, revision) }
                item { BackgroundCard(BackgroundContract.DEVICE, "我的设备", "支持图片、GIF、动态 WebP、MP4 / WebM", Icons.Rounded.PhoneAndroid, true, revision) }
                item { BackgroundCard(BackgroundContract.GLOBAL, "全局背景", "普通 Settings 页面 + 已验证的设备互联页面", Icons.Rounded.Wallpaper, false, revision) }
                item { TextAndSettingsAppearanceCard() }
                item { ModuleAppearanceCard(themeMode, monet, accent, onThemeMode, onMonet, onAccent, revision) }
                item { AuthorCard() }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    @Composable
    private fun HeroCard() {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("HyperOS 背景与外观", style = MiuixTheme.textStyles.title2)
                Text("主页 / 我的设备 / 全局三通道 · LSPosed", color = MiuixTheme.colorScheme.onSurfaceVariantSummary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    MiniPill("Compose")
                    MiniPill("MIUIX")
                    MiniPill("1.3.0")
                }
            }
        }
    }

    @Composable
    private fun MiniPill(label: String) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(MiuixTheme.colorScheme.secondaryContainer)
                .padding(horizontal = 10.dp, vertical = 5.dp)
        ) { Text(label, color = MiuixTheme.colorScheme.onSecondaryContainer) }
    }

    @Composable
    private fun BackgroundCard(slot: String, title: String, summary: String, icon: ImageVector, allowVideo: Boolean, revision: Int) {
        var opacity by remember(slot, revision) { mutableFloatStateOf(prefs.getInt(BackgroundContract.OPACITY_PREFIX + slot, 100).toFloat()) }
        var blur by remember(slot, revision) { mutableStateOf(prefs.getBoolean(BackgroundContract.BLUR_ENABLED_PREFIX + slot, false)) }
        var radius by remember(slot, revision) { mutableFloatStateOf(prefs.getInt(BackgroundContract.BLUR_RADIUS_PREFIX + slot, 20).toFloat()) }
        val file = remember(slot, revision) { File(File(filesDir, "backgrounds"), "$slot.bin") }
        val status = if (file.isFile) "已启用 · ${prefs.getString(BackgroundContract.MIME_PREFIX + slot, "媒体")} · ${humanSize(file.length())}" else "跟随系统默认"

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(vertical = 8.dp)) {
                PreferenceHeader(icon, title, summary, status)
                Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(
                        modifier = Modifier.weight(1f),
                        text = if (allowVideo) "选择媒体" else "选择图片",
                        onClick = {
                            pendingSlot = slot
                            picker.launch(if (allowVideo) arrayOf("image/*", "video/mp4", "video/webm") else arrayOf("image/*"))
                        }
                    )
                    TextButton(
                        modifier = Modifier.weight(1f),
                        text = "恢复默认",
                        onClick = { resetSlot(slot) }
                    )
                }
                SliderPreference("透明度", opacity, 0f..100f, "%") {
                    opacity = it
                    prefs.edit().putInt(BackgroundContract.OPACITY_PREFIX + slot, it.toInt()).apply()
                }
                SwitchPreference(
                    title = "背景模糊",
                    summary = "仅模糊背景媒体，不影响设置内容",
                    checked = blur,
                    onCheckedChange = {
                        blur = it
                        prefs.edit().putBoolean(BackgroundContract.BLUR_ENABLED_PREFIX + slot, it).apply()
                    }
                )
                SliderPreference("模糊强度", radius, 0f..80f, "") {
                    radius = it
                    prefs.edit().putInt(BackgroundContract.BLUR_RADIUS_PREFIX + slot, it.toInt()).apply()
                }
            }
        }
    }

    @Composable
    private fun PreferenceHeader(icon: ImageVector, title: String, summary: String, status: String) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(MiuixTheme.colorScheme.secondaryContainer),
                contentAlignment = Alignment.Center
            ) { Icon(icon, contentDescription = null, tint = MiuixTheme.colorScheme.onSecondaryContainer) }
            Column(Modifier.padding(start = 12.dp).weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MiuixTheme.textStyles.headline1)
                Text(summary, color = MiuixTheme.colorScheme.onSurfaceVariantSummary)
                Text(status, color = MiuixTheme.colorScheme.primary)
            }
        }
    }

    @Composable
    private fun SliderPreference(label: String, value: Float, range: ClosedFloatingPointRange<Float>, suffix: String, onValue: (Float) -> Unit) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label)
                Text("${value.toInt()}$suffix", color = MiuixTheme.colorScheme.onSurfaceVariantActions)
            }
            Slider(value = value, onValueChange = onValue, valueRange = range)
        }
    }

    @Composable
    private fun TextAndSettingsAppearanceCard() {
        var fontMode by remember { mutableIntStateOf(prefs.getInt(BackgroundContract.FONT_MODE, BackgroundContract.FONT_FOLLOW)) }
        var settingsMode by remember { mutableIntStateOf(prefs.getInt(BackgroundContract.SETTINGS_THEME_MODE, BackgroundContract.SETTINGS_THEME_FOLLOW)) }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(vertical = 10.dp)) {
                PreferenceHeader(Icons.Rounded.Settings, "设置应用外观", "这两个选项互相独立", "切换后重新打开“设置”")
                SectionTabs(
                    title = "Settings 深浅模式",
                    labels = listOf("跟随", "浅色", "深色"),
                    selected = settingsMode,
                    onSelected = {
                        settingsMode = it
                        prefs.edit().putInt(BackgroundContract.SETTINGS_THEME_MODE, it).apply()
                    }
                )
                SectionTabs(
                    title = "文字颜色",
                    labels = listOf("跟随", "浅色字", "深色字"),
                    selected = fontMode,
                    onSelected = {
                        fontMode = it
                        prefs.edit().putInt(BackgroundContract.FONT_MODE, it).apply()
                    }
                )
            }
        }
    }

    @Composable
    private fun SectionTabs(title: String, labels: List<String>, selected: Int, onSelected: (Int) -> Unit) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = MiuixTheme.colorScheme.onSurface)
            TabRow(tabs = labels, selectedTabIndex = selected.coerceIn(labels.indices), onTabSelected = onSelected)
        }
    }

    @Composable
    private fun ModuleAppearanceCard(
        themeMode: Int,
        monet: Boolean,
        accent: Int,
        onThemeMode: (Int) -> Unit,
        onMonet: (Boolean) -> Unit,
        onAccent: (Int) -> Unit,
        revision: Int,
    ) {
        var bgOpacity by remember(revision) { mutableFloatStateOf(prefs.getInt(BackgroundContract.UI_BG_OPACITY, 100).toFloat()) }
        var bgBlur by remember(revision) { mutableStateOf(prefs.getBoolean(BackgroundContract.UI_BG_BLUR_ENABLED, false)) }
        var bgRadius by remember(revision) { mutableFloatStateOf(prefs.getInt(BackgroundContract.UI_BG_BLUR_RADIUS, 20).toFloat()) }
        val uiFile = remember(revision) { File(filesDir, "ui_background.bin") }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(vertical = 10.dp)) {
                PreferenceHeader(Icons.Rounded.Palette, "模块外观", "真正的 Compose + MIUIX 界面", if (monet) "Monet 壁纸取色" else String.format("自定义色 #%06X", accent and 0xFFFFFF))
                SectionTabs("界面模式", listOf("跟随", "浅色", "深色"), themeMode, onThemeMode)
                SwitchPreference(
                    title = "Monet 壁纸取色",
                    summary = "跟随当前壁纸生成 MIUIX 动态色",
                    checked = monet,
                    onCheckedChange = onMonet
                )
                AccentPresets(accent, onAccent)
                Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(
                        modifier = Modifier.weight(1f),
                        text = if (uiFile.isFile) "更换模块背景" else "选择模块背景",
                        onClick = {
                            pendingUiBackground = true
                            picker.launch(arrayOf("image/*"))
                        }
                    )
                    TextButton(
                        modifier = Modifier.weight(1f),
                        text = "清除背景",
                        onClick = {
                            if (uiFile.exists()) uiFile.delete()
                            prefs.edit().remove(BackgroundContract.UI_BG_MIME).apply()
                            this@ConfigActivity.revision++
                        }
                    )
                }
                SliderPreference("背景透明度", bgOpacity, 0f..100f, "%") {
                    bgOpacity = it
                    prefs.edit().putInt(BackgroundContract.UI_BG_OPACITY, it.toInt()).apply()
                    this@ConfigActivity.revision++
                }
                SwitchPreference(
                    title = "模块背景模糊",
                    checked = bgBlur,
                    onCheckedChange = {
                        bgBlur = it
                        prefs.edit().putBoolean(BackgroundContract.UI_BG_BLUR_ENABLED, it).apply()
                        this@ConfigActivity.revision++
                    }
                )
                SliderPreference("模块模糊强度", bgRadius, 0f..80f, "") {
                    bgRadius = it
                    prefs.edit().putInt(BackgroundContract.UI_BG_BLUR_RADIUS, it.toInt()).apply()
                    this@ConfigActivity.revision++
                }
            }
        }
    }

    @Composable
    private fun AccentPresets(current: Int, onAccent: (Int) -> Unit) {
        val colors = listOf(0xFF7C8CFF, 0xFF5E8BFF, 0xFF45B6FE, 0xFF36C9A7, 0xFF7EC855, 0xFFFFB84D, 0xFFFF7A59, 0xFFFF6B9A).map { it.toInt() }
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("自定义主题色", color = MiuixTheme.colorScheme.onSurface)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                colors.forEach { c ->
                    Box(
                        Modifier
                            .size(if (c == current) 34.dp else 30.dp)
                            .clip(CircleShape)
                            .background(Color(c))
                            .clickable { onAccent(c) }
                    )
                }
            }
        }
    }

    @Composable
    private fun AuthorCard() {
        val context = LocalContext.current
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val bitmap = remember { runCatching { getDrawable(R.drawable.app_icon)!!.toBitmap(120, 120).asImageBitmap() }.getOrNull() }
                    if (bitmap != null) androidx.compose.foundation.Image(bitmap = bitmap, contentDescription = null, modifier = Modifier.size(58.dp).clip(RoundedCornerShape(18.dp)))
                    Column(Modifier.padding(start = 14.dp).weight(1f)) {
                        Text("制作者 · 苍簇", style = MiuixTheme.textStyles.headline1)
                        Text("HyperBackground 1.3.0", color = MiuixTheme.colorScheme.onSurfaceVariantSummary)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(modifier = Modifier.weight(1f), text = "酷安主页", onClick = { openUrl("https://www.coolapk.com/u/18795532") })
                    TextButton(modifier = Modifier.weight(1f), text = "GitHub", onClick = { openUrl("https://github.com/Solomonstery/HyperBackground") })
                }
                TextButton(modifier = Modifier.fillMaxWidth(), text = "打开模块应用信息", onClick = {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                })
            }
        }
    }

    private fun resetSlot(slot: String) {
        val f = File(File(filesDir, "backgrounds"), "$slot.bin")
        if (f.exists() && !f.delete()) {
            toast("恢复失败")
            return
        }
        prefs.edit().remove(BackgroundContract.MIME_PREFIX + slot).apply()
        revision++
        toast("已恢复系统默认")
    }

    private fun saveFileTo(target: File, uri: Uri) {
        target.parentFile?.mkdirs()
        val temp = File(target.absolutePath + ".tmp")
        if (temp.exists()) temp.delete()
        var total = 0L
        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "无法读取文件" }
            FileOutputStream(temp).use { output ->
                val buffer = ByteArray(65536)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    require(total <= 200L * 1024L * 1024L) { "文件不能超过 200 MB" }
                    output.write(buffer, 0, n)
                }
                output.fd.sync()
            }
        }
        if (target.exists() && !target.delete()) error("无法覆盖旧背景")
        if (!temp.renameTo(target)) error("无法完成文件替换")
        target.setLastModified(System.currentTimeMillis())
    }

    private fun openUrl(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }.onFailure { toast("无法打开链接") }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    companion object {
        private fun humanSize(b: Long): String = when {
            b >= 1048576L -> String.format("%.1f MB", b / 1048576f)
            b >= 1024L -> String.format("%.1f KB", b / 1024f)
            else -> "$b B"
        }
    }
}

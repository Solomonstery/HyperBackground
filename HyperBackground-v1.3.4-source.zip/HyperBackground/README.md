# HyperBackground

HyperOS 设置背景与外观自定义 LSPosed 模块。

> 当前正式版：**1.3.4**
>
> 适配基线：**HyperOS 4 / Android 17**
> 配置界面：**Kotlin + Jetpack Compose + Miuix KMP**

## 正式版 1.3.4

- 使用 Kotlin + Jetpack Compose + Miuix KMP 配置界面，支持浅色、深色和跟随系统。
- 设置主页、我的设备、全局背景三套独立通道。
- 模块无自定义背景时，底色会跟随 MIUIX 深浅主题。
- 支持独立调节模块背景图透明度、模糊与卡片透明度。
- HyperBG 顶部加入“一言”，支持自定义 API 与 JSON 点路径字段。
- 修复自定义主题色始终偏蓝的问题，自定义颜色现作为 MIUIX 动态配色 seed 生效。
- 关于页新增当前版本、最新正式版验证和本次版本说明。
- 移除失效的主题通道实验与背景页冗余介绍卡片。
- 包名与固定签名保持不变，可直接覆盖安装旧版。

## 当前作用域

- `com.android.settings`
- `com.milink.service`

普通 Settings 二级页面使用全局背景；设置主页和“我的设备”分别由独立通道控制。权限确认、账号验证、锁屏凭据和浮动对话框等敏感窗口保持系统原样。

## 安装

1. 从 [GitHub Releases](https://github.com/Solomonstery/HyperBackground/releases) 下载 APK。
2. 安装后在 LSPosed 中启用模块。
3. 勾选模块列出的作用域并结束对应应用进程。
4. 打开 HyperBG 配置图片、透明度、模糊和外观选项。

## 构建环境

- Java 17
- Android SDK 37
- Gradle 9.7.0
- Android Gradle Plugin 9.3.1
- Kotlin 2.4.10
- Compose BOM 2026.08.00
- Miuix KMP 0.9.3

本地构建：

```bash
./build.sh
```

产物位于 `dist/HyperBackground-v<version>.apk`。

## 仓库分支

- `main`：当前可直接构建的仓库根源码。
- `source-archives`：历史源码 ZIP；构建链自动选择版本号最高的源码包。

## 作者

**苍簇**

- 酷安：https://www.coolapk.com/u/18795532
- GitHub：https://github.com/Solomonstery/HyperBackground

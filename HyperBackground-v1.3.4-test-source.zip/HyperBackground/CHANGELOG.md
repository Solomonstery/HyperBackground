# 版本说明

GitHub Actions 会按照 APK 的实际 `versionName` 提取对应章节，并写入 GitHub Release 描述。版本名包含 `test`、`alpha`、`beta`、`rc` 或 `dev` 时会自动标记为 Pre-release。

## 1.3.4-test

- 移除背景页冗余的 HyperOS / Compose / MIUIX 介绍卡片。
- 关于页新增正式版版本验证、最新正式版状态和本次版本说明。
- 修复 Miuix 自定义主题色没有进入 Monet seed 配色流程、导致调色盘始终呈蓝色的问题。
- 正式版检查只读取 GitHub `releases/latest`，不会把 test / alpha / beta / rc 误判为正式更新。
- 包名和固定签名保持不变，可覆盖安装旧版。

## 1.3.3-test

- 完整移除失效的“主题通道实验”，包括配置界面、Provider 字段、Hook 入口与实现类。
- 全局背景继续通过 Activity 生命周期与页面根容器处理，不再拦截系统主题属性。
- README 仅保留当前正式版信息，测试版变更集中到本文件和 GitHub Releases。
- 构建链为正式版和测试版自动生成发行说明、构建信息与固定签名信息。
- 包名和固定签名保持不变，可覆盖安装旧版。

## 1.3.2-test

- 模块无自定义背景时，底色跟随 MIUIX 浅色或深色主题。
- 新增模块卡片透明度，并将原透明度选项明确为背景图透明度。
- HyperBG 大标题下新增“一言”区域，支持刷新、自定义 API 和 JSON 点路径字段。
- 保留主页、我的设备和全局三套独立背景通道。

## 1.3.1

- 配置界面迁移为 Kotlin、Jetpack Compose 与 Miuix KMP。
- 新增浅色、深色、跟随系统、Monet 壁纸取色和自定义主题色。
- 重新组织主页、我的设备和全局背景三通道。
- 保留媒体选择、透明度、模糊、文字颜色和 Settings 外观设置。
- 加入制作者苍簇、酷安与 GitHub 入口。
- 固定模块签名，后续版本可以覆盖安装。

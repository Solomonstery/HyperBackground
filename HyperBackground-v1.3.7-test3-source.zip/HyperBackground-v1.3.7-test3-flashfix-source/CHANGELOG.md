# 版本说明

GitHub Actions 会按照 APK 的实际 `versionName` 提取对应章节，并写入 GitHub Release 描述。版本名包含 `test`、`alpha`、`beta`、`rc` 或 `dev` 时会自动标记为 Pre-release。

## 1.3.7-test3

- MIUIX 二级页面的全局背景仅在识别到 `ActionBarOverlayLayout` 时提升到其根层，不再触碰 DecorView。
- 状态栏、返回栏和大标题区域改为透明，背景图连续延伸到屏幕顶部。
- 直接清除 `ActionBarContainer` 内部绘制的 primary background，解决普通 `View.background` 清理无效的问题。
- 保留应用设置顶部功能卡、隐私页切换条和正文卡片的原生半透明样式。
- 已成功的设备互联与省电管理继续沿用内容层挂载，不进入顶栏提升逻辑。
- 测试版恢复正式包名 `com.ciallo.hyperbackground`，使用与正式版相同的私有 Release 签名并由 GitHub 标记为 Pre-release，可直接覆盖安装。
- 构建作用域校验由 8 项同步为 9 项，加入 `com.xiaomi.misettings`。

## 1.3.7-test2

- 回滚 1.3.7-test 错误的 DecorView 底层挂载，设备互联恢复为 1.3.6 已验证的 `android.R.id.content` 实现。
- 电话服务、小米账号、主题壁纸、手机管家等普通 Android / Miuix 页面统一使用内容层背景，并保留异步布局后的重复挂载。
- 新增 `com.xiaomi.misettings` 作用域，覆盖“健康使用手机”等由独立应用承载的页面。
- 增加 Instrumentation 生命周期兜底，处理未经过标准 Activity 基类回调的页面。
- 正式版与测试版的 Xposed 运行字段按包名隔离，避免两个模块同时安装时会话对象冲突。
- 新增 Hook 读取记录，可直接确认目标进程是否成功注入并读取全局背景。
- 系统桌面为 Flutter / Rust 共享运行时页面，本测试版保留注入诊断，不再使用会导致其他页面回归的通用 Surface 覆盖。
- 测试包继续使用 `com.ciallo.hyperbackground.test` 与调试证书，不覆盖或改动 1.3.6 正式版。

## 1.3.7-test

- 首轮多软件背景 Hook 兼容测试（已由 1.3.7-test2 替代）。

## 1.3.6

- 全局背景新增电话服务、小米账号、主题壁纸、系统桌面、手机管家与省电管理作用域。
- Settings 普通二级页面继续使用全局通道，设置主页与“我的设备”保持独立。
- 登录、授权、锁屏凭据、支付、拨号、紧急呼叫及浮动窗口保持系统原样。
- 调色盘升级为 12 色预设、HSV 色相/饱和度/明度滑杆和可编辑 HEX 输入。
- HEX 输入支持 `#RRGGBB` 与 `#AARRGGBB`，并使用 ASCII 键盘以便输入 A–F。
- 修复本地构建产物文件名没有跟随 APK 实际版本的问题。
- Release 构建改用 GitHub Actions Secrets 注入私有 PKCS#12 密钥；仓库不再保存签名文件或密码。
- 1.3.6 是私有签名迁移起点，与 1.3.5 及更早公开签名不兼容；从本版起保持签名连续。

## 1.3.5

- 移除背景页冗余的 HyperOS / Compose / MIUIX 介绍卡片。
- 关于页新增正式版版本验证、最新正式版状态和本次版本说明。
- 修复 Miuix 自定义主题色没有进入 Monet seed 配色流程、导致调色盘始终呈蓝色的问题。
- 正式版检查只读取 GitHub `releases/latest`，不会把 test / alpha / beta / rc 误判为正式更新。
- 包名和固定签名保持不变，可覆盖安装旧版。

## 1.3.3-test

- 完整移除失效的“主题通道实验”，包括配置界面、Provider 字段、Hook 入口与实现类。
- 全局背景继续通过 Activity 生命周期与页面根容器处理，不再拦截系统主题属性。
- README 仅保留当前正式版信息，测试版变更集中到本文件和 GitHub Releases。
- 构建链为正式版和测试版自动生成发行说明、构建信息与固定签名信息。
- 包名和固定签名保持不变，可覆盖安装旧版。

## 1.3.2-test

- 模块无自定义背景时，底色跟随 MIUIX 浅色或深色主题。
- 新增模块卡片透明度，并将原透明度选项明确为背景图透明度。
- HyperBG 大标题下新增“一言”区域，支持刷新、自定义 API 和 JSON 点路径字段。
- 保留主页、我的设备和全局三套独立背景通道。

## 1.3.1

- 配置界面迁移为 Kotlin、Jetpack Compose 与 Miuix KMP。
- 新增浅色、深色、跟随系统、Monet 壁纸取色和自定义主题色。
- 重新组织主页、我的设备和全局背景三通道。
- 保留媒体选择、透明度、模糊、文字颜色和 Settings 外观设置。
- 加入制作者苍簇、酷安与 GitHub 入口。
- 固定模块签名，后续版本可以覆盖安装。

# HyperBackground 2.0.0

HyperOS / Android 17 Settings LSPosed 背景与界面自定义模块。

## 2.0.0

- 设置首页 / 我的设备双独立背景通道。
- 我的设备 HyperOS 标识：保持系统 Logo / 自定义文本 / 隐藏。
- 自定义 HyperOS 文本内容与颜色。
- 设置卡片模式：跟随系统 / 强制浅色 / 强制深色。该选项只处理卡片表面，不修改文字颜色，与“字体颜色”设置完全独立。
- 模块本体支持浅色 / 深色 / 跟随系统、自定义背景、透明度、模糊、Monet 与可视化主题色。
- 作者：苍簇。

> HyperOS 标识 Hook 优先通过 `miui_version_logo` View ID 定位，因此不依赖原始资源是 VectorDrawable 还是 WebP。不同 ROM 若更改该 ID，会记录 LSPosed 日志并保持系统原样。

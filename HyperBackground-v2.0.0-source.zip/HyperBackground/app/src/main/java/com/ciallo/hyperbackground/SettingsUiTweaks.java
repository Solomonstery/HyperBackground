package com.ciallo.hyperbackground;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

final class SettingsUiTweaks {
    private static final String ORIGINAL_VISIBILITY = "hyperbackground.logo.original.visibility";
    private static final String ORIGINAL_CARD_BG = "hyperbackground.card.original.bg";
    private static final String CUSTOM_LOGO_TAG = "hyperbackground.custom.logo.text";

    private SettingsUiTweaks() {}

    static Activity activityFromFragment(Object fragment) {
        try {
            Object a = XposedHelpers.callMethod(fragment, "getActivity");
            return a instanceof Activity ? (Activity) a : null;
        } catch (Throwable ignored) { return null; }
    }

    static void applyDeviceLogo(Object fragment) {
        if (fragment == null) return;
        try {
            Activity activity = activityFromFragment(fragment);
            if (activity == null) return;
            BackgroundContract.Source cfg = BackgroundContract.query(activity, BackgroundContract.DEVICE);
            View root = null;
            try {
                Object v = XposedHelpers.callMethod(fragment, "getView");
                if (v instanceof View) root = (View) v;
            } catch (Throwable ignored) {}
            if (root == null) root = activity.findViewById(android.R.id.content);
            if (root == null) return;

            int id = activity.getResources().getIdentifier("miui_version_logo", "id", "com.android.settings");
            View logo = id != 0 ? root.findViewById(id) : null;
            if (logo == null && id != 0) logo = activity.findViewById(id);
            if (logo == null) return;

            Object remembered = XposedHelpers.getAdditionalInstanceField(logo, ORIGINAL_VISIBILITY);
            if (!(remembered instanceof Integer)) {
                XposedHelpers.setAdditionalInstanceField(logo, ORIGINAL_VISIBILITY, logo.getVisibility());
                remembered = logo.getVisibility();
            }
            ViewGroup parent = logo.getParent() instanceof ViewGroup ? (ViewGroup) logo.getParent() : null;
            TextView custom = findCustomText(parent);

            if (cfg.deviceLogoMode == BackgroundContract.DEVICE_LOGO_SYSTEM) {
                logo.setVisibility((Integer) remembered);
                if (custom != null) parent.removeView(custom);
                return;
            }

            logo.setVisibility(View.GONE);
            if (cfg.deviceLogoMode == BackgroundContract.DEVICE_LOGO_HIDDEN) {
                if (custom != null) parent.removeView(custom);
                return;
            }
            if (parent == null) return;
            if (custom == null) {
                custom = new TextView(activity);
                custom.setTag(CUSTOM_LOGO_TAG);
                custom.setSingleLine(true);
                custom.setGravity(Gravity.CENTER);
                custom.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                custom.setTextSize(28);
                custom.setPadding(dp(activity, 8), dp(activity, 2), dp(activity, 8), dp(activity, 2));
                int index = parent.indexOfChild(logo);
                ViewGroup.LayoutParams lp = copyLayoutParams(logo.getLayoutParams());
                parent.addView(custom, Math.max(0, index), lp);
            }
            custom.setText(cfg.deviceLogoText == null || cfg.deviceLogoText.trim().isEmpty() ? "HyperOS" : cfg.deviceLogoText);
            custom.setTextColor(cfg.deviceLogoColor);
        } catch (Throwable e) {
            log("applyDeviceLogo", e);
        }
    }

    static void applyCardMode(Activity activity) {
        if (activity == null) return;
        try {
            BackgroundContract.Source cfg = BackgroundContract.query(activity, BackgroundContract.HOME);
            View root = activity.findViewById(android.R.id.content);
            if (root == null) return;
            applyCardRecursive(activity, root, cfg.settingsCardMode);
        } catch (Throwable e) { log("applyCardMode", e); }
    }

    private static void applyCardRecursive(Activity activity, View view, int mode) {
        if (isCardCandidate(activity, view)) {
            Object saved = XposedHelpers.getAdditionalInstanceField(view, ORIGINAL_CARD_BG);
            if (mode == BackgroundContract.CARD_FOLLOW) {
                if (saved instanceof Drawable) {
                    view.setBackground((Drawable) saved);
                    XposedHelpers.removeAdditionalInstanceField(view, ORIGINAL_CARD_BG);
                }
            } else {
                if (!(saved instanceof Drawable) && view.getBackground() != null) {
                    XposedHelpers.setAdditionalInstanceField(view, ORIGINAL_CARD_BG, view.getBackground());
                }
                GradientDrawable d = new GradientDrawable();
                d.setColor(mode == BackgroundContract.CARD_DARK ? Color.rgb(31, 32, 36) : Color.WHITE);
                d.setCornerRadius(dp(activity, 20));
                view.setBackground(d);
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) view;
            for (int i = 0; i < g.getChildCount(); i++) applyCardRecursive(activity, g.getChildAt(i), mode);
        }
    }

    private static boolean isCardCandidate(Activity activity, View view) {
        String className = view.getClass().getName().toLowerCase();
        if (className.contains("cardview") || className.contains("materialcard")) return true;
        int id = view.getId();
        if (id == View.NO_ID || id == 0) return false;
        try {
            String name = activity.getResources().getResourceEntryName(id).toLowerCase();
            return name.contains("card") || name.equals("miui_version_card_view") || name.contains("preference_category");
        } catch (Throwable ignored) { return false; }
    }

    private static TextView findCustomText(ViewGroup parent) {
        if (parent == null) return null;
        for (int i = 0; i < parent.getChildCount(); i++) {
            View child = parent.getChildAt(i);
            if (child instanceof TextView && CUSTOM_LOGO_TAG.equals(child.getTag())) return (TextView) child;
        }
        return null;
    }

    private static ViewGroup.LayoutParams copyLayoutParams(ViewGroup.LayoutParams original) {
        if (original instanceof FrameLayout.LayoutParams) {
            FrameLayout.LayoutParams src = (FrameLayout.LayoutParams) original;
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.gravity = src.gravity;
            lp.leftMargin = src.leftMargin; lp.topMargin = src.topMargin; lp.rightMargin = src.rightMargin; lp.bottomMargin = src.bottomMargin;
            return lp;
        }
        if (original instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams src = (ViewGroup.MarginLayoutParams) original;
            ViewGroup.MarginLayoutParams lp = new ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.leftMargin = src.leftMargin; lp.topMargin = src.topMargin; lp.rightMargin = src.rightMargin; lp.bottomMargin = src.bottomMargin;
            return lp;
        }
        return new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private static int dp(Context context, int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    private static void log(String stage, Throwable e) {
        XposedBridge.log("[HyperBackground] " + stage + " failed: " + e);
        XposedBridge.log(e);
    }
}
